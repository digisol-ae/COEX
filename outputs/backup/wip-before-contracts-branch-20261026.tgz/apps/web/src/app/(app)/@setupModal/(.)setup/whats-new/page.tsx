import { SetupPopup } from '@/app/(app)/setup/workspace-content';
export default function Page() {
  return <SetupPopup section="whats-new" />;
}
