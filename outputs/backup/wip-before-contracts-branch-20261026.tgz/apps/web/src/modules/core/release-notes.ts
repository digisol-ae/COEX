/**
 * What's new in COEX, newest first, in words for the people using it (John, 28 Sep 2026).
 *
 * Describe user-facing features/UI improvements only; keep technical/backend details in handover docs.
 * Owner-requested maintenance entries show counts only.
 * Add a release at the top whenever something users will notice ships. The newest release's id is
 * what "I understand" records on a person's account, so a new entry at the top is all it takes for
 * the drawer to open by itself once more for everyone.
 */

export interface ReleaseNote {
  /** Stable and unique: stored on accounts that have acknowledged it. */
  id: string;
  date: string;
  title: string;
  sections: { heading: string; items: string[] }[];
}

export const RELEASE_NOTES: ReleaseNote[] = [
  {
    id: '2026-10-25-contract-drafting',
    date: '25 October 2026',
    title: 'Prepare customer agreements from reusable templates',
    sections: [
      {
        heading: 'Contract templates and drafting',
        items: [
          'Start with IT Basic, IT Standard, IT Comprehensive or R4 annual support subscription agreements. Create, duplicate and edit additional templates without a fixed template limit.',
          'Open a contract and choose Draft agreement to populate customer details, dates, products and charges. Complete additional fields, edit the full agreement and mark it reviewed before printing or saving a PDF.',
          'Saved agreements keep their wording when a template changes. Internal review notes highlight sample clauses that need attention; signed documents remain linked through Microsoft 365.',
        ],
      },
    ],
  },
  {
    id: '2026-10-25-ticket-search',
    date: '25 October 2026',
    title: 'Find support tickets by more than their subject',
    sections: [
      {
        heading: 'Search your support history',
        items: [
          'Search customer/contact names, emails, phone numbers, descriptions, replies, notes, tags and attachment names, as well as ticket numbers and subjects.',
          'Search includes resolved and closed tickets. Other filters still apply. Use several words to narrow results or put an exact phrase in quotes.',
          'Phone searches accept local, international and formatted numbers. Customer portal searches remain limited to their own public conversations.',
        ],
      },
    ],
  },
  {
    id: '2026-10-25-osticket',
    date: '25 October 2026',
    title: 'Your support history in Worktello',
    sections: [
      {
        heading: 'Support accounts and history',
        items: [
          'Imported customers can choose First time here? at sign-in, verify their email code and set a password.',
          'Your previous support conversations are available on your linked tickets. Attachments from the previous helpdesk will be connected later.',
          'If customer assignment is pending, you can follow your existing tickets. Contact support to link your customer before raising a new ticket.',
        ],
      },
    ],
  },
  {
    id: '2026-10-25-import-review',
    date: '25 October 2026',
    title: 'Clearer imports and customer contacts',
    sections: [
      {
        heading: 'Import with a preview',
        items: [
          'Every CSV template now includes two marked examples, with required fields and formatting instructions beside the download. Remove example rows before uploading your records.',
          'Review possible matches and their reasons before importing. Choose to skip each match; for customers and contacts, you can also create a separate record or update a selected existing record. Blank update fields preserve existing values.',
          'Import and export customer contacts. Link each contact to a customer by its unique name or customer ID, review primary-contact choices, and download the import review report.',
        ],
      },
    ],
  },
  {
    id: '2026-10-25-planning-and-teams',
    date: '25 October 2026',
    title: 'Planning, Teams and data transfer',
    sections: [
      {
        heading: 'Plan your work',
        items: [
          'The Space timeline has adjustable zoom, Today and Fit controls. Move or resize a task to preview its dates, then Save or Discard. Undo last save is available while the dates remain unchanged.',
          'Share a task link to Microsoft Teams from the task page or drawer. Review the preview and choose the recipient in Teams before sending.',
        ],
      },
      {
        heading: 'Work inside Teams',
        items: [
          'Start and stop your task timer, add time manually, and correct your own time with a reason inside the Teams app.',
          'Where your permissions allow, filter tasks by multiple agents and assign tasks to other people. Your existing Space and Folder access still applies.',
        ],
      },
      {
        heading: 'Move your data',
        items: [
          'Administrators with the required access can use Data transfer in Setup to download CSV templates, preview imports, create new records and export accessible records. Supported: tasks, tickets, customers, leads, products and contracts.',
          'Imports create new records and skip recognised duplicates; they do not update existing records. Attachments and chat history are not transferred.',
        ],
      },
      { heading: 'Maintenance', items: ['3 bug fixes and 1 improvement.'] },
    ],
  },
  {
    id: '2026-10-22-maintenance',
    date: '22 October 2026',
    title: 'Bug fixes and improvements',
    sections: [
      {
        heading: 'Maintenance update',
        items: ['3 bug fixes and 1 improvement.'],
      },
    ],
  },
  {
    id: '2026-10-22-teams-pilot',
    date: '22 October 2026',
    title: 'Teams task creation and public policies',
    sections: [
      {
        heading: 'Connected work',
        items: [
          'Now you can create COEX tasks directly from Microsoft Teams messages. Use a message’s More actions menu, choose a Space or Folder, and select an assignee, priority and due date.',
          'The task keeps a link to the original Teams message. Chat history and attachments are not copied. Check the destination before sharing private message content.',
          'Privacy Policy and Terms of Use are now available from the sign-in screen without signing in.',
        ],
      },
    ],
  },
  {
    id: '2026-10-21-agent-summary',
    date: '21 October 2026',
    title: 'Agent updates: tasks, tickets and your workspace',
    sections: [
      {
        heading: 'Tasks and subtasks',
        items: [
          'Finished your assigned subtasks? Choose My subtask done to clear the shared task from your active work and My Desk. Find it under Mine → My subtask done or All my work, and choose Resume my work when needed. New or reopened subtasks bring it back automatically; the main task stays open for your teammates.',
          'Subtask assignments now queue an email with the subtask name and main task link, when assignment emails are enabled. Re-selecting the same person sends no duplicate alert.',
          'Paste, drop or attach screenshots to updates, with thumbnails before posting and image previews afterward. Available on the full task page and half drawer; image-only updates are supported. Limit: 3MB per image, 10MB per update.',
          'The half drawer shows updates newest first, with Show more for older threads. Documents have been removed from the drawer. The main task page has message ordering and the update box above the conversation.',
          'Edit your own updates; edited notes are labelled. Task updates shared with a support ticket stay internal and are never shown to the customer.',
        ],
      },
      {
        heading: 'Support tickets',
        items: [
          'The complete reply box now sits above the conversation. Choose Ascending or Descending message order; use Show more for older messages and Read more for long text.',
          'Transparent message bubbles use purple glow for customers, green for agent replies and red for internal notes. Internal notes remain private.',
          'Paste screenshots into replies and preview attachments before sending. Ticket details, history and common actions are more compact; the sender and raised time stay below the subject.',
          'Where your permissions allow, edit contacts and change the customer/contact linked to an existing ticket. Pages with the update indicator refresh while you are not typing; click it to refresh immediately.',
        ],
      },
      {
        heading: 'Time and navigation',
        items: [
          'Add time manually on a task or ticket when you forgot the timer. Time entries are grouped by person, with dates, notes and totals; visibility follows your existing permissions.',
          'Use the + beside the timer for permitted Task, Ticket or Lead creation. Collapse the sidebar when you need more room.',
          'Navigation has refreshed icons. The active main section has a rainbow background; the selected submenu has a transparent background and rainbow outline.',
        ],
      },
    ],
  },
  {
    id: '2026-10-15',
    date: '15 October 2026',
    title: 'Ticket filter, office time, Done column and more',
    sections: [
      {
        heading: 'Tickets',
        items: [
          'The Tickets list has a new Assigned to picker, so people who may see every ticket can view the tickets of one person. It stays in the address like the other filters.',
          'When a ticket is marked Resolved or Closed, any timer running on it stops by itself and keeps the time it reached.',
        ],
      },
      {
        heading: 'Tasks',
        items: [
          'Start and due times now stay exactly as you type them. A start of 9:00 used to come back as 10:00. All task times are office time (Dubai), the same on every screen.',
          'Spaces: completed tasks stay in the Done column of the board, so everyone can review them without opening a Done tab. The Done button above the board hides them if you prefer.',
          'The Tasks list has a new Created by me filter, to review the tasks you created and follow them up.',
          'Planned hours are gone. Estimate is now the one field for how long a task should take, and it shows on the board, the list and the timeline.',
        ],
      },
      {
        heading: 'Menu',
        items: [
          'The menu now shows the DigiSol logo at the top instead of the workspace name.',
          'Dashboard and My desk are set in bold capitals like the other main headings.',
          'Timesheet is now a main heading of its own, with My timesheet, All timesheets, Time report and Team activity beneath it, instead of sitting under Tasks and planning. The Time icon on the left strip belongs to it too.',
          'Only the page you are on is highlighted: My timesheet no longer lights up while you are on All timesheets.',
        ],
      },
      {
        heading: 'On a phone',
        items: [
          'The phone menu now matches the desktop: the same dark icon strip beside the same panel, with bigger touch targets and the search that was missing on a phone.',
        ],
      },
      {
        heading: 'Notifications',
        items: [
          'New: browser notifications. Open your profile menu (your avatar, top right) and choose Browser notifications to turn them on in this browser. While COEX is open in another tab you get a notification when a customer writes on one of your tickets, or when someone assigns you a task. Click it to open the item. They are off until you switch them on, and they do not reach a closed browser.',
        ],
      },
      {
        heading: 'Time',
        items: [
          'The timesheet lists your open tasks and tickets with no time this week, each with an Add time button, so they no longer wait for a timer to be started.',
          'Time can now be added by hand to a ticket as well as a task, and ticket time shows its ticket number and subject.',
          'A ticket shows its time entries person by person, like a task does.',
        ],
      },
    ],
  },
  {
    id: '2026-10-13',
    date: '13 October 2026',
    title: 'Assigned by me and Dark theme fixes',
    sections: [
      {
        heading: 'Tasks',
        items: [
          'The Tasks list has a new Assigned by me filter. It shows the tasks you assigned to other people. Assignments made before 1 October 2026 were not recorded, so they do not appear.',
        ],
      },
      {
        heading: 'Dark theme',
        items: [
          'The Save button in the Assign agent window is now readable in Dark. It was white on white.',
          'People’s initials in their coloured circles are now dark on the lighter Dark shades, so they are easier to read.',
          'What’s new and the Raise ticket window no longer flash bright white when you point at their close button in Dark.',
          'Windows now dim the page behind them a little more in Dark, so they stand out.',
        ],
      },
    ],
  },
  {
    id: '2026-10-11',
    date: '11 October 2026',
    title: 'Convert leads, the pipeline board and sales reminders',
    sections: [
      {
        heading: 'Leads and opportunities',
        items: [
          "Convert a lead with the customer icon on its row. COEX creates the customer (or adds the lead to one you choose), the contact, and, if you tick it, an opportunity for the salesperson who owns the lead. The lead stays in the list marked Converted, with a link to its customer, and its notes appear on the customer's history.",
          'Opportunities now have a Board view: one column for each pipeline stage, with a card for each deal. Drag a card to another stage, or use the move icon on the card. Dropping a card on Won or Lost, or moving a closed deal, asks for what is needed first.',
          'When you win a deal, COEX offers to create the contract for the sale. The contract form opens already filled in with the customer, the products, the value and the Zoho Books quote number. It is optional, and the contract stays a draft until a manager activates it.',
          "A customer's page now lists that customer's opportunities, and its history shows each next step that was set.",
        ],
      },
      {
        heading: 'Reminders and dashboard',
        items: [
          'The owner of an opportunity gets an email on the day its next step is due, and again when an open opportunity has had no activity for 14 days. Managers can change the number of days under Setup, Pipeline, and switch either email off under Setup, Email.',
          'The dashboard shows My opportunities for people who work on them: how many are in each stage, how many have no next step and how many next steps are overdue.',
        ],
      },
    ],
  },
  {
    id: '2026-10-10',
    date: '10 October 2026',
    title: 'Opportunities and the sales pipeline',
    sections: [
      {
        heading: 'Opportunities',
        items: [
          'A new Opportunities page under CRM tracks potential sales to customers, from first interest to won or lost. Each opportunity has a number such as O-1, a customer and contact, an owner, a one-off value (licence, setup) and a separate recurring value per year (AMC, subscription), a currency, the products, an expected close date and the Zoho Books quote number.',
          'Every deal sits in a pipeline stage: Qualified, Needs analysis, Proposal sent, Negotiation, Won or Lost. Use the move icon to change the stage. Moving a deal to Lost asks why, from a list of reasons. Winning a deal turns a prospect into a client.',
          'Each open deal should have a next step and a date. Deals without one are flagged, and a next step past its date shows as overdue.',
          'You see the opportunities you own; managers and administrators see every one. Totals are shown per currency and are never added across currencies.',
          'Open an opportunity to see its details and its full history. A manager can reopen a won or lost deal by giving a reason.',
          'Managers and administrators can change the stages, their chance of winning and the list of lost reasons under Setup, Pipeline. Administrators decide who works on opportunities in Users and roles.',
        ],
      },
    ],
  },
  {
    id: '2026-10-09',
    date: '9 October 2026',
    title: 'Leads, tickets, folders and time',
    sections: [
      {
        heading: 'All tasks',
        items: [
          'On All tasks you can now filter by one, several or all Spaces, and by one, several or all people, with the same picker style as assigning people.',
          'Add task opens a popup where you choose Personal or any Space, then the folder, people, priority and dates.',
        ],
      },
      {
        heading: 'Tickets',
        items: [
          'Click a ticket subject to open its quick preview, the same way a task title opens its panel. The eye icon is gone. The preview has a full screen icon that opens the whole ticket.',
          'Drag tickets in the list to put them in your own order. The order is yours alone and does not change anyone else\'s list. Sorting a column pauses dragging, and "Reset my order" puts the list back to latest activity first.',
        ],
      },
      {
        heading: 'Folders',
        items: [
          'A folder can now be archived from its settings (the gear beside the folder). Choose to keep its tasks in the space, or to archive the folder together with its tasks. Nothing is deleted for good, logged time is kept, and a running timer stops the archive.',
        ],
      },
      {
        heading: 'Time',
        items: [
          'A short email each morning at 9:00 tells each person how much time they logged the day before: a thank you for a full day, and a polite reminder to log their work honestly when little or nothing was logged. Days off such as Saturday and Sunday are skipped unless you worked. Administrators switch it on, set the target hours and choose who gets the combined summary in Setup, Email.',
          'When a task is shared and several people run their timers, each person now sees only their own time on it ("Your time", "My time" in the list). The hours of everyone are no longer added together on the task. People who may see everyone\'s hours still see each person separately in the task\'s Time entries, with an All people total.',
          'New Team activity page under Time, for people who can see everyone\'s hours: who is working on which task or ticket, the stage it is in, the time they put on it, and a "working now" mark. Filter by days (with a Today button), stage or status, one or several people, and Tasks, Tickets or both. Click a task or ticket for the same quick preview as on Tasks and Support. Share sends the page as a PDF by email, or downloads it.',
          'New time entries are no longer marked billable by default. Tick Billable on the entries that are. Entries already saved keep their setting.',
          "The Time section of a task now lists time entries person by person, each with its date and note. People who may see everyone's timesheets see every person; everyone else sees their own entries.",
        ],
      },
      {
        heading: 'Leads',
        items: [
          'A new Leads page under CRM keeps track of possible customers before they are qualified. Add a lead with its name, company, email, mobile number, source and owner. A lead gets a number such as L-1.',
          'You see the leads you own; managers and administrators see every lead and can filter by owner. Filters with counts show New, Working, Converted and Disqualified leads, and you can search by name, company or email.',
          'If a new lead has the same email, mobile number or company as an existing lead, customer or contact, COEX tells you who it looks like. You can still save it as a new lead.',
          'Mark a lead as working when you start on it. To drop one, disqualify it and say why: the lead stays in the list with your reason, and can be reopened.',
          'Where leads come from is a list you can edit under Setup, Tenant settings. Custom fields can now be added to leads under Setup, Custom fields. Administrators decide who works on leads in Users and roles.',
        ],
      },
    ],
  },
  {
    id: '2026-10-04',
    date: '4 October 2026',
    title: 'Contracts',
    sections: [
      {
        heading: 'Contracts',
        items: [
          'A new Contracts page under CRM lists annual maintenance agreements and other contracts for managers and administrators. Add a contract for a customer with its dates, how often it is billed (monthly, every two months, quarterly or yearly), the amount and currency, the products it covers and a link to the signed document.',
          "A contract shows Expiring when fewer days remain than the customer's warning period (30 by default; change it on the customer under Contract expiry warning) and Expired after its end date.",
          'Renew an active contract with the renew icon: it prepares a draft for the next term, and activating the draft retires the old contract. Contracts that are expiring or have ended are listed at the top of the page.',
          "The contract owner (the customer's owner, or the administrators when there is none) gets an email 60 and 30 days before a contract ends. Switch this on or off under Setup, Email.",
          'Open a contract to see its billing schedule: each period, when its invoice is due, and a "Mark invoiced" tick once finance has invoiced it in Zoho Books. Contracts that count support time show the hours used and left in the current period, as a warning only.',
          "On a ticket, agents now see a notice when the customer's contract is about to end, has ended, or does not exist. When a customer's contract is ending or has ended, the automatic acknowledgement email tells them.",
          'A red number on the CRM icon and beside Contracts counts the contracts that are expiring or have ended. Click it to see just those. The Contracts page has filters with counts: Needs renewal, Expiring in 30 days, Expiring in 60 days and Expired.',
          'Each contract row has an email button that sends a message to the contacts chosen on the contract, one personal email each. Pick a template (renewal reminder, contract ended or general), change the words if you like and check the preview. The templates and a separate Contracts sender address are set under Setup, Email.',
          'If a product is not listed yet, add it from the contract form. Invoices and payments stay in Zoho Books.',
        ],
      },
    ],
  },
  {
    id: '2026-10-03',
    date: '3 October 2026',
    title: 'Ticket improvements, task origins and WhatsApp preparation',
    sections: [
      {
        heading: 'Tickets',
        items: [
          'The ticket scope filters are now colored analytics buttons: Opened (active tickets), Delayed (SLA due within an hour) and Missed (SLA breached). Click a count to see those tickets.',
          'Create a customer directly from the Customer dropdown using their name and email. The saved customer is selected without leaving your ticket draft; edit their details later in Customers.',
          'Add multiple CC collaborators from team, customer or branch contacts, or enter email addresses. Save changes on an existing ticket before replying. Public reply emails include CC; internal notes stay private.',
          'Drop files onto a new ticket or reply, or click to attach. Adding files one by one keeps earlier selections. Each selected file shows an icon, name, size and remove button.',
          'Use the eye icon to preview a ticket without leaving the screen. Compact icon-and-value chips, short message excerpts and hidden empty fields keep the preview small. Open the full ticket from the preview when needed.',
          'The running ticket timer shows a live HH:MM:SS clock next to Stop timer.',
          'Choose a configured sending email in Reply to customer. The current Standard sender remains the default.',
          'When no individual contact or requester email is recorded, public replies use the selected customer’s email address.',
        ],
      },
      {
        heading: 'Tasks',
        items: [
          'To do tasks are yellow; in-progress tasks are blue in task lists and panels.',
          'The Tasks badge counts your visible open assigned tasks. Click the Tasks icon to open that exact list; its tooltip explains the count.',
          'The task creator stays fixed. The editable people field is labelled Assignees, and tasks can still be reassigned.',
          'Tasks show who created them and who assigned them to you, with the date, on the task page, quick preview and side panel. Older assignments whose origin was never recorded are not guessed.',
        ],
      },
      {
        heading: 'WhatsApp preparation',
        items: [
          'Setup, WhatsApp has configuration and test-mode tools for the Support and CRM numbers. Live connectivity still requires configuration.',
          'Support incoming-message handling is prepared: match known mobile numbers, retain unknown sender names and numbers, thread messages into open tickets, and queue a Ticket received acknowledgement when connected. CRM conversations and further WhatsApp reply features remain pending.',
        ],
      },
    ],
  },
  {
    id: '2026-10-01-b',
    date: '1 October 2026',
    title: 'A Back button, task status on the task page, and the right tasks on every list',
    sections: [
      {
        heading: 'Improvements',
        items: [
          'A Back arrow at the top of every screen takes you to the screen you came from.',
          'Change a task’s status straight from the full task page, using the status at the top right.',
          'Tooltips near the edge of the screen now stay fully visible.',
          'Personal now shows only your personal tasks, and each Space shows only its own tasks.',
        ],
      },
    ],
  },
  {
    id: '2026-10-01',
    date: '1 October 2026',
    title: 'My Desk, Personal tasks and over 10 UI improvements',
    sections: [
      {
        heading: 'New',
        items: [
          'My Desk: pick the tasks you commit to today, then choose I am done. Finished tasks move to your Performance History; unfinished ones stay for tomorrow.',
          'The day closes automatically at 23:59, so your history is saved even if you forget.',
          'Personal tasks: a private list only you can see.',
          'Forgot your password? Reset it yourself from the sign in page.',
          'Each Space can now have its own task statuses.',
        ],
      },
      {
        heading: 'Improvements',
        items: [
          'Over 10 UI improvements, including tooltips on every action, larger and clearer icons and colours, quick task previews, easier closing of popups, and compact task cards on phones.',
          'Timesheets can be sorted and show daily and weekly totals.',
        ],
      },
    ],
  },
  {
    id: '2026-09-28',
    date: '28 September 2026',
    title: 'Timers you can place anywhere, and a lighter look',
    sections: [
      {
        heading: 'Timers',
        items: [
          'Timers now live in a small floating window of glass. Drag it anywhere; it stays there as you move between pages.',
          'Three sizes: the full window with today’s timers, a floating digital clock only, or a small bubble that shows a red dot while a timer runs.',
          'The timer button in the header opens and minimizes it.',
        ],
      },
      {
        heading: 'Tickets',
        items: [
          'Any open ticket can now be closed directly, without resolving it first.',
          'Status menus grey out the moves that are not possible, and say why if a change is refused.',
          'Raise ticket opens as a popup over the list instead of pushing the page down.',
        ],
      },
      {
        heading: 'Email',
        items: [
          'Three sending addresses: Standard for customers, Alert for staff alerts, and Admin for account emails.',
          'A new alert when a ticket arrives, for administrators only, the whole desk, or nobody.',
          'Queues have a proper signature editor, with your name and job title filled in automatically.',
          'Preview the acknowledgement, saved replies and signatures exactly as a customer will see them.',
        ],
      },
      {
        heading: 'Spaces',
        items: [
          'Archive a whole space with its folders, tasks and subtasks from Space settings, and restore it from Spaces, Archived spaces.',
        ],
      },
      {
        heading: 'Look and feel',
        items: [
          'The selected item on the left rail glows, and the menu sits on a soft sunset and rainbow background.',
          'Popups use frosted glass. Secondary buttons became small icons: hover over one to see what it does.',
          'Editing or removing time on the timesheet opens in a popup, and asks why the time changed.',
        ],
      },
    ],
  },
  {
    id: '2026-09-27',
    date: '27 September 2026',
    title: 'Themes, your profile, and passwords',
    sections: [
      {
        heading: 'Themes',
        items: [
          'Choose Sunset, Light or Dark from the theme button in the header. Your choice follows you to every device.',
          'Menu headings are bold, and the page you are on is marked with a red bar.',
        ],
      },
      {
        heading: 'Your account',
        items: [
          'Your avatar at the top right opens your menu: Edit profile, Arrange my menu, What’s new and Sign out.',
          'Edit your name and job title in My profile.',
          'Change your password through a link sent to your email, from My profile or with “Forgot your password?” on the sign-in page.',
          'Passwords need at least 12 characters. A few unrelated words make a strong one that is easy to remember.',
        ],
      },
    ],
  },
  {
    id: '2026-09-26',
    date: '26 September 2026',
    title: 'Tickets and tasks work as one',
    sections: [
      {
        heading: 'Tickets and tasks',
        items: [
          'A task raised from a ticket links back to it, and both share one internal conversation.',
          'Type @ in a note to mention a colleague; they get an email.',
          'My work on the dashboard lists your open tickets and tasks together, soonest due first, with a Tickets only / Tasks only filter.',
        ],
      },
      {
        heading: 'Time and menu',
        items: [
          'Changing or removing logged time asks for a reason, shown in that entry’s history.',
          'Arrange my menu lets you put the parts of COEX you use most at the top.',
        ],
      },
    ],
  },
  {
    id: '2026-09-25',
    date: '25 September 2026',
    title: 'COEX goes live for the team',
    sections: [
      {
        heading: 'Support desk',
        items: [
          'Emails to the support mailbox become tickets within seconds, and customer replies join their ticket.',
          'A red dot marks tickets where the customer has written since you last looked, and the Support icon counts them.',
          'The ticket list and ticket page refresh themselves every 30 seconds.',
          'Replies and the acknowledgement stay in one conversation in the customer’s Outlook.',
        ],
      },
    ],
  },
];

export const LATEST_RELEASE_ID = RELEASE_NOTES[0].id;
