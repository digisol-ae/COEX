import { TicketCustomer } from './ticket-customer';
import { listOrganisations } from '@/modules/crm/services/organisation.service';
import { customerReplySenders } from '@/modules/core/services/email.service';
import { listCollaboratorOptions } from '@/modules/tickets/services/collaborator.service';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { asUser, requirePermission } from '@/lib/session';
import { customerReplyAddress, getTicketDetail } from '@/modules/tickets/services/ticket.service';
import { listQueues } from '@/modules/tickets/services/queue.service';
import { listCannedReplies } from '@/modules/tickets/services/canned-reply.service';
import { listUsers } from '@/modules/core/services/user.service';
import { mentionableUsers } from '@/modules/core/services/mention.service';
import { getMyProfile } from '@/modules/core/services/user.service';
import { renderSignature } from '@coex/shared/tickets/email-text';
import { listSpaces } from '@/modules/tasks/services/space.service';
import { CHANNEL_LABELS } from '@/modules/tickets/labels';
import { Card, CardSection, Notice, PageHeader } from '@/components/ui';
import { contractNoticeFor } from '@/modules/crm/services/contract.service';
import { Breadcrumb } from '@/components/ui/breadcrumb';
import { TicketHistory } from './ticket-history';
import { SlaChip } from '@/components/ui/sla';
import { LiveRefresh } from '@/components/ui/live-refresh';
import { formatDateTime } from '@coex/shared/tasks/dates';
import { TimeEntriesByPerson } from '@/modules/time/components/time-entries-by-person';
import { formatMinutes, toDateKey } from '@coex/shared/time/week';
import { getRunningTimer, listTicketTimeByPerson } from '@/modules/time/services/time.service';
import { TicketTimerButton } from '@/modules/time/components/ticket-timer-button';
import { TicketAddTime } from '@/modules/time/components/ticket-add-time';
import { Conversation } from './conversation';
import { ReplyBox } from './reply-box';
import { TicketBar } from './properties';
import { MarkTicketRead } from './mark-read';

export default async function TicketPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ messageOrder?: string }>;
}) {
  const order = (await searchParams).messageOrder === 'desc' ? 'desc' : 'asc';
  const actor = await requirePermission('ticket.read.own');
  const { id } = await params;

  const ticket = await asUser(actor, () => getTicketDetail(id));
  if (!ticket) notFound();

  const seesEverything = actor.permissions.includes('ticket.read.all');
  if (!seesEverything && ticket.assigneeId !== actor.id) notFound();

  const canManage = actor.permissions.includes('ticket.manage');
  const canEditCustomer = canManage && actor.permissions.includes('customer.read');
  const customers = canEditCustomer ? await asUser(actor, () => listOrganisations()) : [];
  const collaboratorOptions = canManage ? await asUser(actor, () => listCollaboratorOptions()) : [];
  const senders = canManage ? await asUser(actor, () => customerReplySenders()) : [];
  const replyEmail = canManage ? await asUser(actor, () => customerReplyAddress(id)) : null;

  const {
    queues,
    users,
    spaces,
    cannedReplies,
    runningTimer,
    timeByPerson,
    people,
    myTitle,
    contractNotice,
  } = await asUser(actor, async () => ({
    queues: await listQueues(),
    users: await listUsers(),
    spaces: actor.permissions.includes('task.manage') ? await listSpaces() : [],
    cannedReplies: await listCannedReplies({ queueId: ticket.queueId }),
    runningTimer: await getRunningTimer(),
    // Other people's hours are for those granted timesheet.read.all; everyone else sees their own.
    timeByPerson: await listTicketTimeByPerson(
      id,
      actor.permissions.includes('timesheet.read.all') ? {} : { onlyUserId: actor.id },
    ),
    people: canManage ? await mentionableUsers() : [],
    myTitle: canManage ? (await getMyProfile()).title : null,
    contractNotice: await contractNoticeFor(ticket.organisationId),
  }));

  // The queue's signature as this person's replies will carry it.
  const signature = renderSignature(ticket.queueSignature, {
    agentName: actor.name,
    agentTitle: myTitle,
    queueName: ticket.queueName,
  });

  const timerRunning = runningTimer?.kind === 'ticket' && runningTimer.itemId === id;

  return (
    <div className="mx-auto max-w-6xl">
      <Breadcrumb
        trail={[
          { label: 'Support', href: '/support/tickets' },
          { label: ticket.queueName, href: `/support/tickets?queue=${ticket.queueId}` },
          { label: ticket.number },
        ]}
      />

      <div className="mt-2 [&>div]:mb-2">
        <PageHeader
          title={ticket.subject}
          description={
            <>
              <span className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
                <span>
                  Created by:{' '}
                  {ticket.requesterEmail ??
                    ticket.messages.find(
                      (message) => message.direction === 'inbound' && message.channel !== 'system',
                    )?.authorName ??
                    ticket.requester ??
                    ticket.contactName ??
                    'Unknown'}
                </span>
                <span>
                  {CHANNEL_LABELS[ticket.channel] ?? ticket.channel} ·{' '}
                  {formatDateTime(ticket.createdAt)}
                </span>
              </span>
              <span className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
                <span>
                  {ticket.organisationName
                    ? `${ticket.organisationName}${ticket.contactName ? ` · ${ticket.contactName}` : ''}`
                    : 'No customer on this ticket yet'}
                </span>
                {canEditCustomer ? (
                  <TicketCustomer
                    id={id}
                    organisationId={ticket.organisationId}
                    contactId={ticket.contactId}
                    customers={customers
                      .filter((c) => c.status === 'active')
                      .map((c) => ({ id: c.id, name: c.name }))}
                  />
                ) : null}
                <SlaChip
                  label="First reply"
                  state={ticket.firstResponseState}
                  dueAt={ticket.firstResponseDueAt}
                />
                <SlaChip
                  label="Resolution"
                  state={ticket.resolutionState}
                  dueAt={ticket.resolutionDueAt}
                />
                <TicketHistory
                  messages={ticket.messages.filter((message) => message.channel === 'system')}
                />
              </span>
            </>
          }
          action={
            <div className="flex flex-col items-end gap-1">
              <span className="font-mono text-[11px] text-[var(--color-ink-subtle)]">
                {ticket.number}
              </span>
              <LiveRefresh />
              <MarkTicketRead ticketId={ticket.id} unread={ticket.unread} />
            </div>
          }
        />
      </div>

      {contractNotice ? (
        <div className="mt-2">
          <Notice tone={contractNotice.state === 'none' ? 'info' : 'warn'}>
            {contractNotice.state === 'none'
              ? 'This customer has no active contract.'
              : contractNotice.state === 'expired'
                ? `Contract ${contractNotice.contractNumber} ended on ${contractNotice.endDate}. Ask the customer about renewing it.`
                : `Contract ${contractNotice.contractNumber} ends on ${contractNotice.endDate}.`}
          </Notice>
        </div>
      ) : null}

      {ticket.mergedIntoId ? (
        <Card className="mt-3 border-[var(--color-status-warn)]">
          <CardSection>
            <p className="text-sm text-[var(--color-ink-muted)]">
              This ticket was merged. The conversation continues on{' '}
              <Link
                href={`/support/tickets/${ticket.mergedIntoId}`}
                className="font-medium text-[var(--color-ink)] underline underline-offset-4"
              >
                the surviving ticket
              </Link>
              .
            </p>
          </CardSection>
        </Card>
      ) : null}

      <div className="mt-2 space-y-3">
        <TicketBar
          ticket={{
            id: ticket.id,
            status: ticket.status,
            priority: ticket.priority,
            queueId: ticket.queueId,
            assigneeId: ticket.assigneeId,
            escalatedTaskId: ticket.escalatedTaskId,
            escalatedTaskNumber: ticket.escalatedTaskNumber,
            linkedTickets: ticket.linkedTickets,
            isOpen: ticket.isOpen,
            isMerged: Boolean(ticket.mergedIntoId),
            firstRespondedAt: ticket.firstRespondedAt,
            resolvedAt: ticket.resolvedAt,
          }}
          queues={queues.map((queue) => ({ id: queue.id, name: queue.name }))}
          users={users.map((user) => ({ id: user.id, name: user.name }))}
          spaces={spaces.map((space) => ({ id: space.id, name: space.name }))}
          canManage={canManage}
          timer={
            <>
              <TicketTimerButton
                compact
                ticketId={ticket.id}
                running={timerRunning}
                startedAt={timerRunning ? runningTimer.startedAt.toISOString() : null}
              />
              <TicketAddTime compact ticketId={ticket.id} />
            </>
          }
          loggedLabel={
            timeByPerson.length > 0
              ? `${formatMinutes(timeByPerson.reduce((sum, person) => sum + person.minutes, 0))} logged`
              : null
          }
          timeEntries={
            <TimeEntriesByPerson
              alwaysExpanded
              people={timeByPerson.map((person) => ({
                userId: person.userId,
                name: person.name,
                minutes: person.minutes,
                entries: person.entries.map((entry) => ({
                  id: entry.id,
                  day: toDateKey(entry.workDate),
                  minutes: entry.minutes,
                  note: entry.note,
                  running: entry.running,
                })),
              }))}
            />
          }
        />

        {canManage && !ticket.mergedIntoId ? (
          <ReplyBox
            ccEmails={ticket.ccEmails}
            collaboratorOptions={collaboratorOptions}
            ticketId={ticket.id}
            emailTo={replyEmail}
            senders={senders}
            people={people}
            cannedReplies={cannedReplies}
            context={{
              contactName: ticket.contactName,
              organisationName: ticket.organisationName,
              agentName: actor.name,
              ticketNumber: ticket.number,
              ticketSubject: ticket.subject,
              // Signed by the server when the queue signs by itself, so the placeholder is blank.
              signature: ticket.queueAutoSign ? '' : signature,
            }}
            autoSignature={ticket.queueAutoSign ? signature : ''}
          />
        ) : null}

        <Conversation
          order={order}
          ticketId={ticket.id}
          messages={ticket.messages.filter((message) => message.channel !== 'system')}
        />
      </div>
    </div>
  );
}
