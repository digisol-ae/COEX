'use client';

import { useActionState, useState } from 'react';
import { Button, Card, CardSection, Field, Input, Notice, Select } from '@/components/ui';
import { useToast } from '@/components/ui/toast';
import { createSpaceAction, type TaskFormState } from '../tasks/actions';

const initialState: TaskFormState = {};

export function NewSpacePanel({
  customers,
  users,
}: {
  customers: { id: string; name: string }[];
  users: { id: string; name: string }[];
}) {
  const [open, setOpen] = useState(false);
  const { showToast } = useToast();
  const [state, formAction, pending] = useActionState(
    async (previous: TaskFormState, formData: FormData) => {
      const result = await createSpaceAction(previous, formData);
      if (result.saved) {
        setOpen(false);
        showToast('Space created.');
      }
      return result;
    },
    initialState,
  );

  if (!open) {
    return <Button onClick={() => setOpen(true)}>Add space</Button>;
  }

  return (
    <Card className="w-full sm:w-96">
      <CardSection title="New space">
        <form action={formAction} className="space-y-3">
          <Field label="Name" hint="For example dOne Platform or Project Management">
            <Input name="name" required autoFocus />
          </Field>

          <Field label="Description">
            <Input name="description" />
          </Field>

          <Field
            label="Folders"
            hint="Optional, separated by commas. Add members to a folder later to make it private."
          >
            <Input name="folders" placeholder="Discovery, Design, Development, Testing" />
          </Field>

          <Field label="Customer" hint="Optional. Work then shows on their timeline.">
            <Select name="organisationId" defaultValue="">
              <option value="">None</option>
              {customers.map((customer) => (
                <option key={customer.id} value={customer.id}>
                  {customer.name}
                </option>
              ))}
            </Select>
          </Field>

          <Field label="Due date">
            <Input name="dueDate" type="date" />
          </Field>

          <Field
            label="Private members"
            hint="Leave empty for a tenant-wide space. Hold command to select several."
          >
            <select
              name="memberIds"
              multiple
              className="h-28 w-full rounded-[var(--radius-control)] border border-[var(--color-line)] bg-[var(--color-surface)] px-2 py-1.5 text-sm text-[var(--color-ink)]"
            >
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.name}
                </option>
              ))}
            </select>
          </Field>

          {state.error ? <Notice tone="alert">{state.error}</Notice> : null}

          <div className="flex gap-2">
            <Button type="submit" disabled={pending}>
              {pending ? 'Creating' : 'Create'}
            </Button>
            <Button type="button" variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
          </div>
        </form>
      </CardSection>
    </Card>
  );
}
