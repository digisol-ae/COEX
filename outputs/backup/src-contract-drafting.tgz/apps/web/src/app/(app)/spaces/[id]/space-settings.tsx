'use client';
import { SettingsDrawer } from '@/components/ui/settings-drawer';
import { StatusEditor } from '@/components/tasks/status-editor';

import { useActionState, useState } from 'react';
import { Button, Field, Input, Notice } from '@/components/ui';
import { useToast } from '@/components/ui/toast';
import { updateSpaceAction, type TaskFormState } from '../../tasks/actions';
import { ArchiveSpace } from './archive-space';

const initialState: TaskFormState = {};

export function SpaceSettings({
  space,
  users,
  customers,
}: {
  space: {
    id: string;
    name: string;
    description: string | null;
    memberIds: string[];
    statuses: { name: string; isClosed: boolean }[];
    organisationId: string | null;
  };
  users: { id: string; name: string }[];
  customers: { id: string; name: string }[];
}) {
  const [open, setOpen] = useState(false);
  const { showToast } = useToast();
  const [state, action, pending] = useActionState(
    async (previous: TaskFormState, formData: FormData) => {
      const result = await updateSpaceAction(previous, formData);
      if (result.saved) {
        setOpen(false);
        showToast('Space saved.');
      }
      return result;
    },
    initialState,
  );
  if (!open)
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        title="Space settings"
        aria-label="Space settings"
        className="ml-2 flex h-7 w-7 items-center justify-center rounded-full text-[var(--color-ink-muted)] hover:bg-[var(--color-surface-muted)] hover:text-[var(--color-ink)]"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path
            d="M12 15.25a3.25 3.25 0 1 0 0-6.5 3.25 3.25 0 0 0 0 6.5Z"
            stroke="currentColor"
            strokeWidth="1.8"
          />
          <path
            d="m19.4 15 .1-1.2 1.7-1.3-1.8-3.1-2 .8-1-.6-.3-2.1H12.5l-.3 2.1-1 .6-2-.8-1.8 3.1 1.7 1.3.1 1.2-1.7 1.3 1.8 3.1 2-.8 1 .6.3 2.1h3.6l.3-2.1 1-.6 2 .8 1.8-3.1-1.7-1.3Z"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinejoin="round"
          />
        </svg>
      </button>
    );
  return (
    <SettingsDrawer title="Space settings" open={open} onClose={() => setOpen(false)}>
      <form action={action} className="w-full space-y-3 text-left">
        <input type="hidden" name="id" value={space.id} />
        <Field label="Space name">
          <Input name="name" defaultValue={space.name} required />
        </Field>
        <Field label="Description">
          <Input name="description" defaultValue={space.description ?? ''} />
        </Field>
        <Field label="Customer" hint="Optional. Work then shows on their timeline.">
          <select
            name="organisationId"
            defaultValue={space.organisationId ?? ''}
            className="w-full rounded-[var(--radius-control)] border border-[var(--color-line)] bg-[var(--color-surface)] px-2 py-1.5 text-sm"
          >
            <option value="">None</option>
            {customers.map((customer) => (
              <option key={customer.id} value={customer.id}>
                {customer.name}
              </option>
            ))}
          </select>
        </Field>
        <Field
          label="Private members"
          hint="Leave empty so everyone in the tenant can see this space. Hold command to select several."
        >
          <select
            name="memberIds"
            multiple
            defaultValue={space.memberIds}
            className="h-28 w-full rounded-[var(--radius-control)] border border-[var(--color-line)] bg-[var(--color-surface)] px-2 py-1.5 text-sm"
          >
            {users.map((user) => (
              <option key={user.id} value={user.id}>
                {user.name}
              </option>
            ))}
          </select>
        </Field>
        <StatusEditor initial={space.statuses} />
        {state.error ? <Notice tone="alert">{state.error}</Notice> : null}
        <div className="mt-4 flex justify-end gap-2">
          <Button type="button" variant="secondary" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button type="submit" disabled={pending}>
            {pending ? 'Saving' : 'Save settings'}
          </Button>
        </div>
        <ArchiveSpace spaceId={space.id} spaceName={space.name} />
      </form>
    </SettingsDrawer>
  );
}
