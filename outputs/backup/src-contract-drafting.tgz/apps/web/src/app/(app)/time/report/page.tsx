import { asUser, requirePermission } from '@/lib/session';
import { loadTotals } from '@/modules/time/services/timesheet.service';
import { formatMinutes, startOfWeek } from '@coex/shared/time/week';
import { Card, CardSection, EmptyState, PageHeader, Table, Td, Th } from '@/components/ui';
import { IconLink } from '@/components/ui/icon-button';
import { PeriodPicker } from './period-picker';
import { toDateKey } from '@coex/shared/time/week';

export const metadata = { title: 'Time report · Worktello' };

/**
 * Where the hours went, three ways.
 *
 * Billable is shown beside total everywhere rather than as a separate report, because the useful
 * question is never "how many hours" on its own.
 */
export default async function TimeReportPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string }>;
}) {
  const actor = await requirePermission('timesheet.read.all');
  const params = await searchParams;

  const from = params.from ? new Date(params.from) : startOfWeek(new Date());
  const to = params.to ? new Date(params.to) : new Date();
  const toExclusive = new Date(to);
  toExclusive.setHours(23, 59, 59, 999);

  const totals = await asUser(actor, () => loadTotals(from, toExclusive));

  const exportHref = `/time/report/export?from=${toDateKey(from)}&to=${toDateKey(to)}`;

  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader
        title="Time report"
        description="Hours by person, space and customer for the period, with billable shown beside each total."
        action={
          <IconLink
            icon="download"
            label="Download this report as CSV"
            prefetch={false}
            href={exportHref}
          />
        }
      />

      <PeriodPicker from={toDateKey(from)} to={toDateKey(to)} />

      <div className="mt-4 grid grid-cols-2 gap-3">
        <Card className="px-4 py-3">
          <p className="text-xs font-medium tracking-wide text-[var(--color-ink-subtle)] uppercase">
            Total
          </p>
          <p className="mt-1 text-lg font-medium text-[var(--color-ink)] tabular-nums">
            {formatMinutes(totals.totalMinutes)}
          </p>
        </Card>

        <Card className="px-4 py-3">
          <p className="text-xs font-medium tracking-wide text-[var(--color-ink-subtle)] uppercase">
            Billable
          </p>
          <p className="mt-1 text-lg font-medium text-[var(--color-ink)] tabular-nums">
            {formatMinutes(totals.billableMinutes)}
          </p>
        </Card>
      </div>

      <div className="mt-6 space-y-6">
        <Group title="By person" rows={totals.byPerson} />
        <Group title="By space" rows={totals.bySpace} />
        <Group title="By customer" rows={totals.byCustomer} />
      </div>
    </div>
  );
}

function Group({
  title,
  rows,
}: {
  title: string;
  rows: { id: string; label: string; minutes: number; billableMinutes: number }[];
}) {
  return (
    <Card>
      <CardSection title={title}>
        {rows.length === 0 ? (
          <EmptyState message="No time recorded in this period." />
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Name</Th>
                <Th>Hours</Th>
                <Th>Billable</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr
                  key={row.id || row.label}
                  data-sort-values={JSON.stringify([row.label, row.minutes, row.billableMinutes])}
                >
                  <Td className="text-[var(--color-ink)]">{row.label}</Td>
                  <Td className="tabular-nums text-[var(--color-ink-muted)]">
                    {formatMinutes(row.minutes)}
                  </Td>
                  <Td className="tabular-nums text-[var(--color-ink-muted)]">
                    {formatMinutes(row.billableMinutes)}
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </CardSection>
    </Card>
  );
}
