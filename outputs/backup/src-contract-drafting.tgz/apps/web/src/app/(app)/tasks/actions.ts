'use server';
import {
  MAX_FILE_BYTES,
  MAX_MESSAGE_ATTACHMENT_BYTES,
  PROCESSED_IMAGE_TYPES,
  type IncomingFile,
} from '@/modules/tickets/services/attachment.service';
import { validateSpaceStatuses } from '@coex/shared/tasks/statuses';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { asUser, requirePermission } from '@/lib/session';
import {
  setMySubtaskDone,
  addDocumentLink,
  addTaskComment,
  addSubtask,
  archiveTask,
  createTask,
  deleteTaskUpdate,
  editTaskUpdate,
  moveTask,
  moveTaskToSpace,
  moveTaskToPosition,
  patchTask,
  removeDocumentLink,
  setSubtaskAssignee,
  toggleSubtask,
  updateTask,
  type Priority,
} from '@/modules/tasks/services/task.service';
import {
  archiveImpact,
  archiveSpace,
  createSpace,
  personalSpaceForCurrentUser,
  reorderSpaces,
  restoreSpace,
  updateSpace,
} from '@/modules/tasks/services/space.service';
import {
  archiveFolder,
  createFolder,
  reorderFolders,
  updateFolder,
} from '@/modules/tasks/services/folder.service';

function subtaskError(error: unknown, fallback: string): string {
  const expected = [
    'Task not found.',
    'Subtask not found.',
    'A subtask can only go to someone already assigned to its task.',
    'That person is not a member of this private Space or Folder.',
    'Complete your assigned subtasks first.',
    'Only an assignee can change their own subtask completion.',
  ];
  if (error instanceof Error && expected.includes(error.message)) return error.message;
  console.error('Subtask update failed:', error);
  return fallback;
}

export interface TaskFormState {
  error?: string;
  saved?: boolean;
}

const PRIORITIES = ['urgent', 'high', 'normal', 'low'] as const;

function text(formData: FormData, field: string): string {
  return String(formData.get(field) ?? '').trim();
}

function toPriority(value: string): Priority {
  return (PRIORITIES as readonly string[]).includes(value) ? (value as Priority) : 'normal';
}

function assigneesFrom(formData: FormData): string[] {
  return formData.getAll('assigneeIds').map(String).filter(Boolean);
}

export async function createSpaceAction(
  _previous: TaskFormState,
  formData: FormData,
): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');

  let id: string;

  try {
    id = await asUser(actor, () =>
      createSpace({
        name: text(formData, 'name'),
        description: text(formData, 'description'),
        organisationId: text(formData, 'organisationId') || null,
        dueDate: text(formData, 'dueDate') || null,
        memberIds: formData.getAll('memberIds').map(String).filter(Boolean),
      }),
    );

    // Folders typed on the create form are made straight away, so a new space opens with somewhere
    // to put work rather than with an empty page and a second form to find.
    const names = text(formData, 'folders')
      .split(',')
      .map((name) => name.trim())
      .filter(Boolean);

    for (const name of names) {
      await asUser(actor, () => createFolder({ spaceId: id, name }));
    }
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not create the space.' };
  }

  revalidatePath('/spaces');
  redirect(`/spaces/${id}`);
}

export async function updateSpaceAction(
  _previous: TaskFormState,
  formData: FormData,
): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');
  const id = text(formData, 'id');
  try {
    await asUser(actor, () =>
      updateSpace(id, {
        name: text(formData, 'name'),
        description: text(formData, 'description'),
        organisationId: text(formData, 'organisationId') || null,
        dueDate: formData.has('dueDate') ? text(formData, 'dueDate') || null : undefined,
        memberIds: formData.getAll('memberIds').map(String).filter(Boolean),
        statuses: formData.has('statuses')
          ? validateSpaceStatuses(JSON.parse(text(formData, 'statuses')))
          : undefined,
      }),
    );
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not update the space.' };
  }
  revalidatePath(`/spaces/${id}`);
  revalidatePath('/spaces');
  revalidatePath('/tasks');
  revalidatePath('/my-desk');
  return { saved: true };
}

/** Persisting a drag reorder of the Spaces list. */
export async function reorderSpacesAction(orderedIds: string[]): Promise<{ error?: string }> {
  const actor = await requirePermission('task.manage');

  try {
    await asUser(actor, () => reorderSpaces(orderedIds));
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not save the new order.' };
  }

  revalidatePath('/spaces');
  return {};
}

/** Persisting a drag reorder of one space's folders, from the sidebar tree. */
export async function reorderFoldersAction(
  spaceId: string,
  orderedIds: string[],
): Promise<{ error?: string }> {
  const actor = await requirePermission('task.manage');

  try {
    await asUser(actor, () => reorderFolders(spaceId, orderedIds));
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not save the new order.' };
  }

  revalidatePath(`/spaces/${spaceId}`);
  return {};
}

export async function createTaskAction(
  _previous: TaskFormState,
  formData: FormData,
): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');
  const spaceId = text(formData, 'spaceId');

  try {
    await asUser(actor, () =>
      createTask({
        spaceId,
        title: text(formData, 'title'),
        description: text(formData, 'description'),
        priority: toPriority(text(formData, 'priority')),
        assigneeIds: assigneesFrom(formData),
        startAt: text(formData, 'startAt') || null,
        endAt: text(formData, 'endAt') || null,
        folderId: text(formData, 'folderId') || null,
        estimateMinutes: text(formData, 'estimateHours')
          ? Math.round(Number(text(formData, 'estimateHours')) * 60)
          : null,
      }),
    );
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not create the task.' };
  }

  revalidatePath(`/spaces/${spaceId}`);
  revalidatePath('/tasks');
  revalidatePath('/dashboard');
  return { saved: true };
}

/** Captures a task from My tasks without asking the agent to create or choose a Space. */
export async function createPersonalTaskAction(
  _previous: TaskFormState,
  formData: FormData,
): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');
  try {
    await asUser(actor, async () => {
      const spaceId = await personalSpaceForCurrentUser();
      await createTask({
        spaceId,
        title: text(formData, 'title'),
        priority: toPriority(text(formData, 'priority')),
        assigneeIds: [actor.id],
        endAt: text(formData, 'endAt') || null,
      });
    });
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not create the task.' };
  }
  revalidatePath('/tasks');
  revalidatePath('/dashboard');
  return { saved: true };
}

/**
 * The New task popup on All tasks (John, 9 Oct 2026): one form that creates the task in Personal
 * or in any Space, with its folder, people, priority and dates. Personal tasks go to the signed-in
 * person, as before; for a Space the service applies its private Space and Folder rules.
 */
export async function createTaskAnywhereAction(
  _previous: TaskFormState,
  formData: FormData,
): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');
  const destination = text(formData, 'spaceId');

  try {
    await asUser(actor, async () => {
      const personal = destination === 'personal';
      const spaceId = personal ? await personalSpaceForCurrentUser() : destination;
      if (!spaceId) throw new Error('Choose where the task goes.');

      await createTask({
        spaceId,
        title: text(formData, 'title'),
        description: text(formData, 'description'),
        priority: toPriority(text(formData, 'priority')),
        assigneeIds: personal ? [actor.id] : assigneesFrom(formData),
        startAt: text(formData, 'startAt') || null,
        endAt: text(formData, 'endAt') || null,
        folderId: personal ? null : text(formData, 'folderId') || null,
      });
    });
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not create the task.' };
  }

  revalidatePath('/tasks');
  revalidatePath('/spaces');
  revalidatePath('/personal');
  revalidatePath('/dashboard');
  return { saved: true };
}

/**
 * Adding a task from the foot of a column or a group.
 *
 * A title and nothing else, straight into the column it was typed under. Capture and detail are
 * different moments: making someone fill a form to write down a thought is how thoughts stop
 * getting written down, and everything else about the task can be set from the row afterwards.
 */
export async function quickAddTaskAction(input: {
  spaceId: string;
  title: string;
  status: string;
  folderId?: string | null;
}): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');

  const title = input.title.trim();
  if (!title) return { error: 'A task needs a title.' };

  try {
    await asUser(actor, () =>
      createTask({
        spaceId: input.spaceId,
        title,
        status: input.status,
        folderId: input.folderId ?? null,
      }),
    );
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not add the task.' };
  }

  revalidatePath(`/spaces/${input.spaceId}`);
  revalidatePath('/tasks');
  revalidatePath('/dashboard');
  return { saved: true };
}

/** Used by drag and drop, which sends the neighbours rather than an index. */
export async function reorderTaskAction(input: {
  id: string;
  spaceId: string;
  status: string;
  afterTaskId: string | null;
  beforeTaskId: string | null;
}): Promise<void> {
  const actor = await requirePermission('task.manage');

  await asUser(actor, () =>
    moveTaskToPosition(input.id, input.status, input.afterTaskId, input.beforeTaskId),
  );

  revalidatePath(`/spaces/${input.spaceId}`);
  revalidatePath('/tasks');
  revalidatePath('/dashboard');
}

/**
 * Status from the full task page. Returns the refusal rather than throwing, so the page can say
 * why a change did not stick instead of showing a generic error.
 */
export async function setTaskStatusAction(input: {
  id: string;
  spaceId: string;
  status: string;
}): Promise<{ error?: string }> {
  const actor = await requirePermission('task.manage');

  try {
    await asUser(actor, () => moveTask(input.id, input.status));
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'The status could not be changed.' };
  }

  revalidatePath(`/spaces/${input.spaceId}`);
  revalidatePath(`/tasks/${input.id}`);
  revalidatePath('/tasks');
  revalidatePath('/dashboard');
  return {};
}

export async function moveTaskAction(formData: FormData): Promise<void> {
  const actor = await requirePermission('task.manage');
  const id = text(formData, 'id');

  await asUser(actor, () => moveTask(id, text(formData, 'status')));

  revalidatePath(`/spaces/${text(formData, 'spaceId')}`);
  revalidatePath(`/tasks/${id}`);
  revalidatePath('/tasks');
  revalidatePath('/dashboard');
}

export async function addTaskCommentAction(
  _previous: TaskFormState,
  formData: FormData,
): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');
  const id = text(formData, 'taskId');

  try {
    const entries = formData
      .getAll('files')
      .filter((entry): entry is File => typeof entry !== 'string' && entry.size > 0);
    if (entries.some((file) => file.size > MAX_FILE_BYTES))
      return { error: 'Each image must be 3MB or smaller.' };
    if (entries.reduce((sum, file) => sum + file.size, 0) > MAX_MESSAGE_ATTACHMENT_BYTES)
      return { error: 'Images total more than 10MB.' };
    if (entries.some((file) => !PROCESSED_IMAGE_TYPES.has(file.type)))
      return { error: 'Use PNG, JPEG or WebP images for task updates.' };
    const images: IncomingFile[] = await Promise.all(
      entries.map(async (file) => ({
        fileName: file.name,
        contentType: file.type,
        body: Buffer.from(await file.arrayBuffer()),
      })),
    );
    await asUser(actor, () =>
      addTaskComment(id, text(formData, 'body'), mentionIdsFrom(formData), images),
    );
  } catch (error) {
    const expected = [
      'Write a comment before posting it.',
      'A comment can be up to 4,000 characters.',
      'Task not found.',
      'One image could not be read. Please choose a valid PNG, JPEG or WebP image.',
      'Use PNG, JPEG or WebP images for task updates.',
      'Each image must be 3MB or smaller.',
      'Images total more than 10MB. Send a cloud link instead.',
    ];
    if (error instanceof Error && expected.includes(error.message)) return { error: error.message };
    console.error('Task update failed:', error);
    return { error: 'Could not post your update. Please try again.' };
  }

  revalidatePath(`/tasks/${id}`);
  return { saved: true };
}

export async function updateTaskAction(
  _previous: TaskFormState,
  formData: FormData,
): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');
  const id = text(formData, 'id');

  try {
    await asUser(actor, () =>
      updateTask(id, {
        title: text(formData, 'title'),
        description: text(formData, 'description'),
        priority: toPriority(text(formData, 'priority')),
        assigneeIds: assigneesFrom(formData),
        startAt: text(formData, 'startAt') || null,
        endAt: text(formData, 'endAt') || null,
        estimateMinutes: text(formData, 'estimateHours')
          ? Math.round(Number(text(formData, 'estimateHours')) * 60)
          : null,
        folderId: text(formData, 'folderId') || null,
        tags: text(formData, 'tags')
          .split(',')
          .map((tag) => tag.trim())
          .filter(Boolean),
      }),
    );
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not save the task.' };
  }

  revalidatePath(`/tasks/${id}`);
  return { saved: true };
}

/**
 * Inline edits from a card or a row.
 *
 * These come from a click on the board, not from a form, so they take arguments rather than
 * FormData and send only the field that changed.
 */
export async function patchTaskAction(input: {
  id: string;
  spaceId: string;
  priority?: 'urgent' | 'high' | 'normal' | 'low';
  startAt?: string | null;
  endAt?: string | null;
  assigneeIds?: string[];
  title?: string;
  description?: string | null;
  tags?: string[];
}): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');

  try {
    await asUser(actor, () =>
      patchTask(input.id, {
        priority: input.priority,
        startAt: input.startAt,
        endAt: input.endAt,
        assigneeIds: input.assigneeIds,
        title: input.title,
        description: input.description,
        tags: input.tags,
      }),
    );
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not save the change.' };
  }

  revalidatePath(`/spaces/${input.spaceId}`);
  revalidatePath(`/tasks/${input.id}`);
  revalidatePath('/tasks');
  revalidatePath('/dashboard');
  return { saved: true };
}

/** Adding a subtask from the panel, which has to refresh the space page too. */
export async function addSubtaskInlineAction(input: {
  taskId: string;
  title: string;
  spaceId: string;
}): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');

  const title = input.title.trim();
  if (!title) return { error: 'A subtask needs a title.' };

  try {
    await asUser(actor, () => addSubtask(input.taskId, title));
  } catch (error) {
    return { error: subtaskError(error, 'Could not add this subtask. Please try again.') };
  }

  revalidatePath(`/spaces/${input.spaceId}`);
  revalidatePath(`/tasks/${input.taskId}`);
  return { saved: true };
}

/** The subtask checkbox inside the space list, which has to refresh the space page too. */
export async function setSubtaskDoneAction(input: {
  taskId: string;
  subtaskId: string;
  done: boolean;
  spaceId: string;
}): Promise<{ error?: string }> {
  const actor = await requirePermission('task.manage');
  try {
    await asUser(actor, () => toggleSubtask(input.taskId, input.subtaskId, input.done));
  } catch (error) {
    return { error: subtaskError(error, 'Could not update this subtask. Please try again.') };
  }

  revalidatePath(`/spaces/${input.spaceId}`);
  revalidatePath(`/tasks/${input.taskId}`);
  return {};
}

/** Give a subtask to a member (or clear it) from the board panel or the task page. */
export async function setSubtaskAssigneeAction(input: {
  taskId: string;
  subtaskId: string;
  assigneeId: string | null;
  spaceId?: string;
}): Promise<{ error?: string }> {
  const actor = await requirePermission('task.manage');

  try {
    await asUser(actor, () => setSubtaskAssignee(input.taskId, input.subtaskId, input.assigneeId));
  } catch (error) {
    return { error: subtaskError(error, 'Could not assign this subtask. Please try again.') };
  }

  if (input.spaceId) revalidatePath(`/spaces/${input.spaceId}`);
  revalidatePath(`/tasks/${input.taskId}`);
  return {};
}

export async function addSubtaskAction(formData: FormData): Promise<{ error?: string }> {
  const actor = await requirePermission('task.manage');
  const id = text(formData, 'taskId');
  const title = text(formData, 'title');
  if (!title.trim()) return { error: 'Enter a title for the subtask.' };
  try {
    await asUser(actor, () => addSubtask(id, title));
  } catch (error) {
    return { error: subtaskError(error, 'Could not add this subtask. Please try again.') };
  }
  revalidatePath(`/tasks/${id}`);
  return {};
}

export async function toggleSubtaskAction(formData: FormData): Promise<{ error?: string }> {
  const actor = await requirePermission('task.manage');
  const id = text(formData, 'taskId');
  try {
    await asUser(actor, () =>
      toggleSubtask(id, text(formData, 'subtaskId'), text(formData, 'done') !== 'true'),
    );
  } catch (error) {
    return { error: subtaskError(error, 'Could not update this subtask. Please try again.') };
  }
  revalidatePath('/', 'layout');
  return {};
}

export async function addDocumentAction(
  _previous: TaskFormState,
  formData: FormData,
): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');
  const id = text(formData, 'taskId');

  try {
    await asUser(actor, () => addDocumentLink(id, text(formData, 'url'), text(formData, 'title')));
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not add the link.' };
  }

  revalidatePath(`/tasks/${id}`);
  return { saved: true };
}

export async function removeDocumentAction(formData: FormData): Promise<void> {
  const actor = await requirePermission('task.manage');
  const id = text(formData, 'taskId');

  await asUser(actor, () => removeDocumentLink(id, text(formData, 'linkId')));

  revalidatePath(`/tasks/${id}`);
}

export async function archiveTaskAction(formData: FormData): Promise<void> {
  const actor = await requirePermission('task.manage');

  await asUser(actor, () => archiveTask(text(formData, 'id')));

  revalidatePath('/tasks');
  redirect('/tasks');
}

/* Folders: the second level, and the only place visibility is decided. */

export async function saveFolderAction(
  _previous: TaskFormState,
  formData: FormData,
): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');

  const id = text(formData, 'id');
  const spaceId = text(formData, 'spaceId');

  const input = {
    spaceId,
    name: text(formData, 'name'),
    description: text(formData, 'description') || null,
    memberIds: formData.getAll('memberIds').map(String).filter(Boolean),
  };

  try {
    await asUser(actor, async () => {
      if (id) await updateFolder(id, input);
      else await createFolder(input);
    });
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not save the folder.' };
  }

  revalidatePath(`/spaces/${spaceId}`);
  revalidatePath('/spaces');
  return { saved: true };
}

/** Creating a folder from the tree, where there is room for a name and nothing else. */
export async function quickAddFolderAction(input: {
  spaceId: string;
  name: string;
  privateToMe?: boolean;
}): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');

  const name = input.name.trim();
  if (!name) return { error: 'A folder needs a name.' };

  try {
    await asUser(actor, () =>
      createFolder({
        spaceId: input.spaceId,
        name,
        memberIds: input.privateToMe ? [actor.id] : [],
      }),
    );
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not add the folder.' };
  }

  revalidatePath(`/spaces/${input.spaceId}`);
  revalidatePath('/spaces');
  return { saved: true };
}

/** Creating a space from the tree, same idea. */
export async function quickAddSpaceAction(input: { name: string }): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');

  const name = input.name.trim();
  if (!name) return { error: 'A space needs a name.' };

  try {
    await asUser(actor, () => createSpace({ name }));
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not add the space.' };
  }

  revalidatePath('/spaces');
  return { saved: true };
}

/**
 * Archiving a folder.
 *
 * The work inside comes out into the space rather than disappearing with the folder, because a
 * folder is a way of grouping and removing it should not remove what was grouped. "Archive with its
 * tasks" is the explicit second choice (John, 9 Oct 2026). Returns an error rather than throwing so
 * a running timer is explained in the popup.
 */
export async function archiveFolderAction(formData: FormData): Promise<TaskFormState> {
  const actor = await requirePermission('task.manage');

  const id = text(formData, 'id');
  const spaceId = text(formData, 'spaceId');
  const withTasks = text(formData, 'withTasks') === 'yes';

  try {
    await asUser(actor, () => archiveFolder(id, { withTasks }));
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not archive the folder.' };
  }

  revalidatePath(`/spaces/${spaceId}`);
  revalidatePath('/spaces');
  return { saved: true };
}

/** The people picked with @ in a note, sent by the mention picker as one hidden field each. */
function mentionIdsFrom(formData: FormData): string[] {
  return formData.getAll('mentionIds').map(String).filter(Boolean);
}

/** How much archiving a Space would take with it, for the confirmation step. */
export async function spaceArchiveImpactAction(
  id: string,
): Promise<{ tasks?: number; folders?: number; error?: string }> {
  const actor = await requirePermission('task.manage');
  try {
    return await asUser(actor, () => archiveImpact(id));
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not check the space.' };
  }
}

export async function archiveSpaceAction(id: string): Promise<{ error?: string }> {
  const actor = await requirePermission('task.manage');
  try {
    await asUser(actor, () => archiveSpace(id));
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not archive the space.' };
  }
  // The space leaves the menu, lists and My tasks everywhere.
  revalidatePath('/', 'layout');
  return {};
}

export async function restoreSpaceAction(id: string): Promise<{ error?: string }> {
  const actor = await requirePermission('task.manage');
  try {
    await asUser(actor, () => restoreSpace(id));
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not restore the space.' };
  }
  revalidatePath('/', 'layout');
  return {};
}

/** Moves a task from Personal into a Space, and a Folder if one is chosen, in its first column. */
export async function moveTaskToSpaceAction(
  taskId: string,
  spaceId: string,
  folderId: string | null,
): Promise<{ error?: string }> {
  const actor = await requirePermission('task.manage');

  try {
    await asUser(actor, () => moveTaskToSpace(taskId, { spaceId, folderId }));
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not move the task.' };
  }

  revalidatePath('/personal');
  revalidatePath('/tasks');
  revalidatePath(`/spaces/${spaceId}`);
  return {};
}

/** The author changes the text of their own work update; it then shows "edited". */
export async function editTaskUpdateAction(input: {
  taskId: string;
  commentId: string;
  body: string;
}): Promise<{ error?: string }> {
  const actor = await requirePermission('task.manage');

  try {
    await asUser(actor, () => editTaskUpdate(input.taskId, input.commentId, input.body));
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not save the change.' };
  }

  revalidatePath(`/tasks/${input.taskId}`);
  return {};
}

/** The author, or an administrator, removes a task's own work update from view. */
export async function deleteTaskUpdateAction(input: {
  taskId: string;
  commentId: string;
}): Promise<{ error?: string }> {
  const actor = await requirePermission('task.manage');

  try {
    await asUser(actor, () => deleteTaskUpdate(input.taskId, input.commentId));
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Could not delete the update.' };
  }

  revalidatePath(`/tasks/${input.taskId}`);
  return {};
}

export async function setMySubtaskDoneAction(
  taskId: string,
  done: boolean,
): Promise<{ error?: string }> {
  const actor = await requirePermission('task.read.own');
  try {
    await asUser(actor, () => setMySubtaskDone(taskId, done));
  } catch (error) {
    return { error: subtaskError(error, 'Could not update your work. Please try again.') };
  }
  revalidatePath('/', 'layout');
  return {};
}
