'use client';

import Link from 'next/link';
import { Captcha } from '@/components/ui/captcha';
import { useState } from 'react';
import { useActionState } from 'react';
import { Button, Field, Input, Notice } from '@/components/ui';
import { loginAction, type LoginState } from './actions';

const initialState: LoginState = {};

export function LoginForm({
  customer = false,
  entraEnabled = false,
  entraError,
}: {
  customer?: boolean;
  entraEnabled?: boolean;
  entraError?: string;
}) {
  const [state, formAction, pending] = useActionState(loginAction, initialState);
  const [showPassword, setShowPassword] = useState(false);

  return (
    <form action={formAction} className="mt-8 space-y-4">
      {entraError ? (
        <Notice tone="alert">
          {entraError === 'account'
            ? 'Your Microsoft account is not authorised for Worktello.'
            : entraError === 'not-configured'
              ? 'Microsoft sign-in is not configured yet.'
              : 'Microsoft sign-in was not completed. Please try again.'}
        </Notice>
      ) : null}
      {entraEnabled ? (
        <>
          {/* eslint-disable-next-line @next/next/no-html-link-for-pages -- This authentication route handler requires a full redirect, not client page navigation. */}
          <a
            href="/api/auth/entra"
            className="block w-full rounded-[var(--radius-control)] border border-[var(--color-line-strong)] px-4 py-2.5 text-center text-sm font-medium text-[var(--color-ink)] hover:bg-[var(--color-surface-muted)]"
          >
            Continue with Microsoft
          </a>
          <div className="flex items-center gap-3 text-xs text-[var(--color-ink-subtle)] before:h-px before:flex-1 before:bg-[var(--color-line)] after:h-px after:flex-1 after:bg-[var(--color-line)]">
            or
          </div>
        </>
      ) : null}
      <Field label={customer ? 'Email address or osTicket username' : 'Email address'}>
        <Input
          name="email"
          type={customer ? 'text' : 'email'}
          maxLength={254}
          autoComplete="username"
          required
        />
      </Field>

      <Field label="Password">
        <div className="relative">
          <Input
            name="password"
            type={showPassword ? 'text' : 'password'}
            autoComplete="current-password"
            required
            className="pr-9"
          />
          <button
            type="button"
            onClick={() => setShowPassword((value) => !value)}
            aria-label={showPassword ? 'Hide password' : 'Show password'}
            aria-pressed={showPassword}
            className="absolute inset-y-0 right-0 flex w-9 items-center justify-center text-[var(--color-ink-subtle)] hover:text-[var(--color-ink)]"
          >
            {showPassword ? <EyeOffIcon /> : <EyeIcon />}
          </button>
        </div>
      </Field>

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="rememberMe" className="h-4 w-4" />
        Remember me on this PC for 60 days
      </label>
      <Captcha action="login" pending={pending} />
      {state.error ? <Notice tone="alert">{state.error}</Notice> : null}

      <Button type="submit" disabled={pending} className="w-full py-2.5">
        {pending ? 'Signing in' : 'Sign in'}
      </Button>

      {customer ? (
        <p className="text-center text-sm">
          <Link href="/email-login" className="font-semibold underline">
            Sign in with an email code
          </Link>
        </p>
      ) : null}
      <p className="text-center text-sm">
        <Link
          href="/forgot-password"
          className="text-[var(--color-ink-muted)] underline-offset-4 hover:text-[var(--color-ink)] hover:underline"
        >
          Forgot your password?
        </Link>
      </p>
    </form>
  );
}

function EyeIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path
        d="M1 8s2.5-5 7-5 7 5 7 5-2.5 5-7 5-7-5-7-5Z"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinejoin="round"
      />
      <circle cx="8" cy="8" r="2.2" stroke="currentColor" strokeWidth="1.3" />
    </svg>
  );
}

function EyeOffIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path
        d="M2 2l12 12M6.6 6.7A2.2 2.2 0 0 0 8 10.2c.5 0 1-.17 1.35-.45M4.2 4.5C2.6 5.6 1 8 1 8s2.5 5 7 5c1.2 0 2.25-.35 3.1-.85M9.9 5.15C9.35 5.05 8.7 5 8 5c-.4 0-.78.02-1.13.06M11.3 6.2c1.15.9 1.7 1.8 1.7 1.8s-.35.7-1 1.5"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
