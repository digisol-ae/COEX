import { taskTeamsSource, teamsMessageLink } from '@coex/shared/tasks/teams-sharing';
import { fileStorage } from '@/lib/storage';
import { storeTaskImages, type IncomingFile } from '@/modules/tickets/services/attachment.service';
import { Types } from 'mongoose';
import { connectToDatabase } from '@/lib/db';
import { getContext } from '@/lib/tenant-context';
import { repository } from '@/lib/repository';
import { toObjectId, toOptionalObjectId } from '@/lib/ids';
import { recordAudit, changedFields } from '@/modules/core/services/audit.service';
import { nextNumber } from '@/modules/core/services/numbering.service';
import { recordActivity } from '@/modules/crm/services/activity.service';
import { UserModel } from '@coex/shared/core/models/user.model';
import { TaskModel } from '@coex/shared/tasks/models/task.model';
import { TaskCommentModel } from '@coex/shared/tasks/models/task-comment.model';
import { alertStaff, appBaseUrl } from '@/modules/core/services/email.service';
import {
  alertMentioned,
  mentionableUsers,
  type MentionableUser,
} from '@/modules/core/services/mention.service';
import { SpaceModel } from '@coex/shared/tasks/models/space.model';
import { FolderModel } from '@coex/shared/tasks/models/folder.model';
import { TimeEntryModel } from '@coex/shared/time/models/time-entry.model';
import { assignableMemberIds, canOpenFolder, visibleFolderFilter } from './folder.service';
import { assignableSpaceMemberIds, canOpenSpace, visibleSpaceFilter } from './space.service';
import { actorIsAdministrator } from './access.service';
import { parseDocumentLink } from '@coex/shared/tasks/document-links';
import { TicketModel } from '@coex/shared/tickets/models/ticket.model';
import { TicketMessageModel } from '@coex/shared/tickets/models/ticket-message.model';
import { parseDateTimeInput } from '@coex/shared/tasks/dates';

/**
 * Tasks.
 *
 * isClosed is denormalised from the space's column configuration whenever the status changes, so
 * the dashboard counts open work with one indexed query rather than joining to the space on
 * every tile. lastActivityAt is touched on every meaningful change, which is what the ageing view
 * reads.
 */

const tasks = () => repository(TaskModel);
const taskComments = () => repository(TaskCommentModel);

function toDate(value: string | null | undefined): Date | null {
  // Typed times are office time (Asia/Dubai), not the server's own clock; see shared/tasks/dates.
  return parseDateTimeInput(value);
}

export type Priority = 'urgent' | 'high' | 'normal' | 'low';

export interface TaskSummary {
  id: string;
  number: string;
  title: string;
  status: string;
  priority: Priority;
  spaceId: string;
  spaceName: string;
  folderId: string | null;
  folderName: string | null;
  assigneeIds: string[];
  assigneeNames: string[];
  startAt: Date | null;
  endAt: Date | null;
  estimateMinutes: number | null;
  sortOrder: number;
  subtaskCount: number;
  subtasksDone: number;
  subtasks: { id: string; title: string; done: boolean; assigneeId: string | null }[];
  sourceTeamsMessageUrl?: string | null;
  documentCount: number;
  documentLinks: { id: string; title: string; url: string }[];
  /** The signed-in person's own logged time on this task, not everyone's added together. */
  loggedMinutes: number;
  isClosed: boolean;
  isOverdue: boolean;
  lastActivityAt: Date;
}

export interface TaskFilter {
  /** Only these tasks, for screens that already know which ones they need. */
  ids?: string[];
  personalWork?: 'active' | 'done' | 'all';
  spaceId?: string;
  /** Any of these spaces; used by the All tasks screen's space picker. */
  spaceIds?: string[];
  folderId?: string;
  assigneeId?: string;
  /** Assigned to any of these people. */
  assigneeIds?: string[];
  status?: string;
  includeClosed?: boolean;
  overdueOnly?: boolean;
  unassignedOnly?: boolean;
  /** Tasks this person assigned to someone else; an assignment to themselves does not count. */
  assignedById?: string;
  /** Tasks this person created, whoever they are assigned to. */
  createdById?: string;
}

/**
 * Open tasks someone else put the signed-in person on since a moment, for browser notifications.
 * Same Space and Folder visibility as the lists, so a notification never names work the person
 * could not open. A person assigning themselves is not news.
 */
export async function listNewAssignmentsToMe(
  since: Date,
): Promise<{ id: string; number: string; title: string; assignedByName: string; at: Date }[]> {
  await connectToDatabase();

  const me = getContext().userId;
  const found = await TaskModel.find({
    $and: [
      {
        tenantId: getContext().tenantId,
        deletedAt: null,
        isClosed: false,
        assignments: {
          $elemMatch: { userId: me, assignedAt: { $gt: since }, assignedById: { $ne: me } },
        },
      },
      await visibleFolderFilter(),
      await visibleSpaceFilter('spaceId'),
    ].filter((condition) => Object.keys(condition).length > 0),
  })
    .select('number title assignments')
    .limit(20);

  const rows = found.flatMap((task) =>
    task.assignments
      .filter(
        (entry) =>
          String(entry.userId) === String(me) &&
          entry.assignedAt > since &&
          String(entry.assignedById) !== String(me),
      )
      .map((entry) => ({ task, entry })),
  );

  const people = await UserModel.find({
    _id: { $in: [...new Set(rows.map(({ entry }) => String(entry.assignedById)))] },
  }).select('name');
  const names = new Map(people.map((person) => [String(person._id), person.name]));

  return rows.map(({ task, entry }) => ({
    id: String(task._id),
    number: task.number,
    title: task.title,
    assignedByName: names.get(String(entry.assignedById)) ?? 'Someone',
    at: entry.assignedAt,
  }));
}

export async function listTasks(filter: TaskFilter = {}): Promise<TaskSummary[]> {
  await connectToDatabase();

  const query: Record<string, unknown> = {};

  if (filter.ids) query._id = { $in: filter.ids.map(toObjectId) };
  if (filter.spaceId) query.spaceId = toObjectId(filter.spaceId);
  else if (filter.spaceIds?.length) query.spaceId = { $in: filter.spaceIds.map(toObjectId) };
  if (filter.folderId) query.folderId = toObjectId(filter.folderId);
  if (filter.assigneeId) query.assigneeIds = toObjectId(filter.assigneeId);
  else if (filter.assigneeIds?.length) {
    query.assigneeIds = { $in: filter.assigneeIds.map(toObjectId) };
  }
  const personalWork =
    filter.personalWork ?? (filter.assigneeId === String(getContext().userId) ? 'active' : 'all');
  if (personalWork !== 'all') {
    query.mySubtaskDoneByIds =
      personalWork === 'done'
        ? toObjectId(String(getContext().userId))
        : { $ne: toObjectId(String(getContext().userId)) };
  }
  if (filter.status) query.status = filter.status;
  if (!filter.includeClosed) query.isClosed = false;
  if (filter.overdueOnly) query.endAt = { $lt: new Date() };
  if (filter.unassignedOnly) query.assigneeIds = { $size: 0 };
  if (filter.createdById) query.createdById = toObjectId(filter.createdById);
  if (filter.assignedById) {
    // Only assignments recorded since 1 Oct 2026 carry who made them, so older ones cannot match.
    query.assignments = {
      $elemMatch: {
        assignedById: toObjectId(filter.assignedById),
        userId: { $ne: toObjectId(filter.assignedById) },
      },
    };
  }

  // Private folders are filtered here rather than in a screen, so nothing that reads tasks can
  // forget to apply it. The conditions are joined with $and, never spread into one object: the
  // space visibility filter also sets spaceId, and spreading it replaced the space asked for, so
  // Personal and every Space page listed every visible task (fixed 1 Oct 2026).
  const conditions = [
    query,
    await visibleFolderFilter(),
    await visibleSpaceFilter('spaceId'),
  ].filter((condition) => Object.keys(condition).length > 0);
  const found = await tasks()
    .find(conditions.length > 0 ? { $and: conditions } : {})
    .sort({ sortOrder: 1, endAt: 1, createdAt: -1 });

  const spaceNames = new Map(
    (await SpaceModel.find({ tenantId: getContext().tenantId, deletedAt: null })).map((space) => [
      String(space._id),
      space.name,
    ]),
  );

  const folderNames = new Map(
    (await FolderModel.find({ tenantId: getContext().tenantId, deletedAt: null })).map((folder) => [
      String(folder._id),
      folder.name,
    ]),
  );

  const assigneeIds = [
    ...new Set(found.flatMap((task) => task.assigneeIds.map((id) => String(id)))),
  ];
  const users = await UserModel.find({ _id: { $in: assigneeIds } }).select('name');
  const names = new Map(users.map((user) => [String(user._id), user.name]));

  // Batched the same way documentCount and subtaskCount are, so a list of a hundred tasks costs
  // one extra query rather than one per task. A running entry has not yet had its minutes written,
  // so its live elapsed time is added in here rather than waiting for it to stop.
  // Only the signed-in person's own time: summing every assignee's timer made a shared task look
  // like it had taken the hours of all of them together (John, 10 Oct 2026).
  const timeEntries = await TimeEntryModel.find({
    tenantId: getContext().tenantId,
    userId: toObjectId(String(getContext().userId)),
    taskId: { $in: found.map((task) => task._id) },
    deletedAt: null,
  }).select('taskId minutes running startedAt createdAt');

  const nowMs = Date.now();
  const loggedByTask = new Map<string, number>();

  for (const entry of timeEntries) {
    const key = String(entry.taskId);
    const startedAt = entry.startedAt ?? entry.createdAt;
    const minutes = entry.running
      ? Math.max(0, Math.floor((nowMs - startedAt.getTime()) / 60000))
      : (entry.minutes ?? 0);

    loggedByTask.set(key, (loggedByTask.get(key) ?? 0) + minutes);
  }

  const now = new Date();

  return found.map((task) => ({
    sourceTeamsMessageUrl: taskTeamsSource(task.sourceTeamsMessageUrl, task.description),
    id: String(task._id),
    number: task.number,
    title: task.title,
    status: task.status,
    priority: task.priority as Priority,
    spaceId: String(task.spaceId),
    spaceName: spaceNames.get(String(task.spaceId)) ?? 'Unknown',
    folderId: task.folderId ? String(task.folderId) : null,
    folderName: task.folderId ? (folderNames.get(String(task.folderId)) ?? null) : null,
    assigneeIds: task.assigneeIds.map((id) => String(id)),
    assigneeNames: task.assigneeIds.map((id) => names.get(String(id)) ?? 'Unknown'),
    startAt: task.startAt ?? null,
    endAt: task.endAt ?? null,
    estimateMinutes: task.estimateMinutes ?? null,
    sortOrder: task.sortOrder ?? 0,
    subtaskCount: task.subtasks.length,
    subtasksDone: task.subtasks.filter((subtask) => subtask.done).length,
    subtasks: task.subtasks.map((subtask) => ({
      id: String(subtask._id),
      title: subtask.title,
      done: subtask.done,
      assigneeId: subtask.assigneeId ? String(subtask.assigneeId) : null,
    })),
    documentCount: task.documentLinks.length,
    documentLinks: task.documentLinks.map((link) => ({
      id: String(link._id),
      title: link.title,
      url: link.url,
    })),
    loggedMinutes: loggedByTask.get(String(task._id)) ?? 0,
    isClosed: task.isClosed ?? false,
    isOverdue: !task.isClosed && !!task.endAt && task.endAt < now,
    lastActivityAt: task.lastActivityAt ?? task.updatedAt,
  }));
}

/**
 * How much open work is mine, for the badge on the rail.
 *
 * One counted query on an indexed field, because this runs on every page load and a badge is never
 * worth a slow screen.
 */
export async function countMyOpenTasks(userId: string): Promise<number> {
  await connectToDatabase();

  const conditions = [
    {
      assigneeIds: toObjectId(userId),
      isClosed: false,
      mySubtaskDoneByIds: { $ne: toObjectId(userId) },
    },
    await visibleFolderFilter(),
    await visibleSpaceFilter('spaceId'),
  ].filter((condition) => Object.keys(condition).length > 0);
  return tasks().count({ $and: conditions });
}

export async function getTask(id: string) {
  await connectToDatabase();
  const task = await tasks().findById(id);
  if (!task || !(await canOpenSpace(String(task.spaceId)))) return null;
  if (task.folderId && !(await canOpenFolder(String(task.folderId)))) return null;
  return task;
}

/** Personal completion never closes the shared task or removes its assignee. */
export async function setMySubtaskDone(taskId: string, done: boolean): Promise<void> {
  const task = await getTask(taskId);
  const actor = getContext().userId;
  if (!task || !task.assigneeIds.some((id) => String(id) === String(actor))) {
    throw new Error('Only an assignee can change their own subtask completion.');
  }
  const query: Record<string, unknown> = { _id: task._id, assigneeIds: actor };
  if (done) {
    query.subtasks = { $not: { $elemMatch: { assigneeId: actor, done: false } } };
  }
  const saved = await tasks().updateOne(
    query,
    done ? { $addToSet: { mySubtaskDoneByIds: actor } } : { $pull: { mySubtaskDoneByIds: actor } },
  );
  if (!saved) throw new Error('Complete your assigned subtasks first.');
}

export interface TaskCommentView {
  attachments: { id: string; fileName: string; contentType: string; bytes: number }[];
  isSystem?: boolean;
  id: string;
  body: string;
  authorName: string;
  createdAt: Date;
  editedAt: Date | null;
  /** The author may change the text of their own update. */
  canEdit: boolean;
  /** The author, or an administrator, may delete a task's own update. Ticket notes are never deleted. */
  canDelete: boolean;
}

/**
 * The ticket a task was escalated from. Tasks escalated before sourceTicketId was written only
 * carry the link on the ticket side, so fall back to that rather than silently dropping updates.
 */
async function sourceTicketIdFor(task: {
  _id: Types.ObjectId;
  sourceTicketId?: Types.ObjectId | null;
}): Promise<Types.ObjectId | null> {
  if (task.sourceTicketId) return task.sourceTicketId;
  const ticket = await TicketModel.findOne({
    tenantId: getContext().tenantId,
    escalatedTaskId: task._id,
  })
    .select('_id')
    .lean<{ _id: Types.ObjectId }>();
  return ticket?._id ?? null;
}

/** The ticket a task came from, for the link back to it on the task screen. */
export async function sourceTicketFor(task: {
  _id: Types.ObjectId;
  sourceTicketId?: Types.ObjectId | null;
}): Promise<{ id: string; number: string; subject: string } | null> {
  const ticketId = await sourceTicketIdFor(task);
  if (!ticketId) return null;
  const ticket = await TicketModel.findOne({ _id: ticketId, tenantId: getContext().tenantId })
    .select('number subject')
    .lean<{ number: string; subject: string }>();
  return ticket ? { id: String(ticketId), number: ticket.number, subject: ticket.subject } : null;
}

/**
 * A task's conversation. For a task raised from a ticket it is that ticket's internal notes, the one
 * conversation both screens show and answer (John, 26 Sep 2026), so nothing is stored twice and
 * nothing drifts apart. Other tasks keep their own notes. Neither is ever emailed to a customer.
 */
export type TaskOrigin = {
  createdBy: { name: string; at: string } | null;
  /** One per current assignee whose assignment was recorded. */
  assignedBy: { userId: string; byName: string; at: string }[];
};

/**
 * Who created a task and who gave it to each assignee, in names a person can read (John,
 * 1 Oct 2026). A missing creator or assigner is left out rather than guessed.
 */
export async function taskOrigin(task: {
  createdById?: Types.ObjectId | null;
  createdAt?: Date | null;
  assignments?: Iterable<Assignment> | null;
}): Promise<TaskOrigin> {
  const assignments = Array.from(task.assignments ?? []);
  const ids = [
    ...(task.createdById ? [String(task.createdById)] : []),
    ...assignments.flatMap((entry) => (entry.assignedById ? [String(entry.assignedById)] : [])),
  ];
  const people = await UserModel.find({ _id: { $in: [...new Set(ids)] } }).select('name');
  const names = new Map(people.map((person) => [String(person._id), person.name]));

  const creator = task.createdById ? names.get(String(task.createdById)) : undefined;
  return {
    createdBy:
      creator && task.createdAt ? { name: creator, at: task.createdAt.toISOString() } : null,
    assignedBy: assignments.flatMap((entry) => {
      // Putting yourself on your own task is not news (John's team, 18 Oct 2026), so it is not listed.
      if (String(entry.assignedById) === String(entry.userId)) return [];
      const byName = entry.assignedById ? names.get(String(entry.assignedById)) : undefined;
      return byName
        ? [{ userId: String(entry.userId), byName, at: entry.assignedAt.toISOString() }]
        : [];
    }),
  };
}

export async function taskUpdateImage(taskId: string, attachmentId: string) {
  const task = await getTask(taskId);
  if (!task) return null;
  const sourceTicketId = await sourceTicketIdFor(task);
  const record = sourceTicketId
    ? await TicketMessageModel.findOne({
        tenantId: getContext().tenantId,
        ticketId: sourceTicketId,
        visibility: 'internal',
        'attachments._id': toObjectId(attachmentId),
      })
    : await taskComments().findOne({
        taskId: task._id,
        deletedAt: null,
        'attachments._id': toObjectId(attachmentId),
      });
  const attachment = record?.attachments?.find((item) => String(item._id) === attachmentId);
  if (!attachment) return null;
  return {
    fileName: attachment.fileName,
    contentType: attachment.contentType,
    body: await fileStorage().get(attachment.storageKey),
  };
}

export async function listTaskComments(taskId: string): Promise<TaskCommentView[]> {
  const task = await getTask(taskId);
  if (!task) return [];

  const sourceTicketId = await sourceTicketIdFor(task);
  if (sourceTicketId) {
    const notes = await TicketMessageModel.find({
      tenantId: getContext().tenantId,
      ticketId: sourceTicketId,
      visibility: 'internal',
    }).sort({ sentAt: 1 });

    const actors = await UserModel.find({
      tenantId: getContext().tenantId,
      _id: {
        $in: notes
          .filter((note) => note.channel === 'system' && note.authorUserId)
          .map((note) => note.authorUserId),
      },
    }).select('name');
    const actorNames = new Map(actors.map((user) => [String(user._id), user.name]));
    return notes.map((note) => ({
      attachments: (note.attachments ?? []).map((a) => ({
        id: String(a._id),
        fileName: a.fileName,
        contentType: a.contentType,
        bytes: a.bytes,
      })),
      isSystem: note.channel === 'system',
      id: String(note._id),
      body: note.body,
      authorName:
        note.channel === 'system' && note.authorName === 'COEX'
          ? (actorNames.get(String(note.authorUserId)) ?? 'Worktello')
          : note.authorName,
      createdAt: note.sentAt ?? note.createdAt,
      editedAt: note.editedAt ?? null,
      canEdit:
        note.channel !== 'system' && String(note.authorUserId) === String(getContext().userId),
      // A ticket's notes are its record: they can be corrected here, never removed.
      canDelete: false,
    }));
  }

  const administrator = await actorIsAdministrator();
  const found = await taskComments()
    .find({ taskId: toObjectId(taskId), deletedAt: null })
    .sort({ createdAt: 1 });

  return found.map((comment) => {
    const own = String(comment.authorUserId) === String(getContext().userId);

    return {
      attachments: (comment.attachments ?? []).map((a) => ({
        id: String(a._id),
        fileName: a.fileName,
        contentType: a.contentType,
        bytes: a.bytes,
      })),
      id: String(comment._id),
      body: comment.body,
      authorName: comment.authorName,
      createdAt: comment.createdAt,
      editedAt: comment.editedAt ?? null,
      canEdit: own,
      canDelete: own || administrator,
    };
  });
}

/**
 * Changes the text of a work update (John's team, 17 Oct 2026). Only its author may, and the
 * update shows "edited" afterwards. The old text is kept in the audit record. Mentions are not
 * emailed again, so correcting a typo never pings anybody twice. On a task raised from a ticket the
 * update is the ticket's internal note, so the same edit shows on both.
 */
export async function editTaskUpdate(
  taskId: string,
  commentId: string,
  body: string,
): Promise<void> {
  const text = body.trim();
  if (!text) throw new Error('An update cannot be empty. Delete it instead.');
  if (text.length > 4_000) throw new Error('A comment can be up to 4,000 characters.');

  const task = await getTask(taskId);
  if (!task) throw new Error('Task not found.');

  const context = getContext();
  const sourceTicketId = await sourceTicketIdFor(task);
  const now = new Date();

  if (sourceTicketId) {
    const note = await TicketMessageModel.findOne({
      _id: toObjectId(commentId),
      tenantId: context.tenantId,
      ticketId: sourceTicketId,
      visibility: 'internal',
    });
    if (!note) throw new Error('Update not found.');
    if (String(note.authorUserId) !== String(context.userId)) {
      throw new Error('Only the person who wrote an update can change it.');
    }

    await TicketMessageModel.updateOne({ _id: note._id }, { $set: { body: text, editedAt: now } });
    await recordAudit({
      action: 'task.update_edited',
      entityType: 'Task',
      entityId: task._id,
      before: { body: note.body },
      after: { body: text, ticketNote: String(note._id) },
    });
    return;
  }

  const comment = await taskComments().findOne({
    _id: toObjectId(commentId),
    taskId: task._id,
    deletedAt: null,
  });
  if (!comment) throw new Error('Update not found.');
  if (String(comment.authorUserId) !== String(context.userId)) {
    throw new Error('Only the person who wrote an update can change it.');
  }

  await taskComments().updateOne({ _id: comment._id }, { $set: { body: text, editedAt: now } });
  await recordAudit({
    action: 'task.update_edited',
    entityType: 'Task',
    entityId: task._id,
    before: { body: comment.body },
    after: { body: text },
  });
}

/**
 * Removes a work update from view. Its author or an administrator may; the text stays in the
 * database and the audit record. A task raised from a ticket keeps its updates, because they are the
 * ticket's internal notes and a ticket's record is never erased.
 */
export async function deleteTaskUpdate(taskId: string, commentId: string): Promise<void> {
  const task = await getTask(taskId);
  if (!task) throw new Error('Task not found.');
  if (await sourceTicketIdFor(task)) {
    throw new Error('These updates are the ticket’s internal notes and cannot be deleted.');
  }

  const context = getContext();
  const comment = await taskComments().findOne({
    _id: toObjectId(commentId),
    taskId: task._id,
    deletedAt: null,
  });
  if (!comment) throw new Error('Update not found.');

  const own = String(comment.authorUserId) === String(context.userId);
  if (!own && !(await actorIsAdministrator())) {
    throw new Error('Only the person who wrote an update, or an administrator, can delete it.');
  }

  await taskComments().updateOne({ _id: comment._id }, { $set: { deletedAt: new Date() } });
  await recordAudit({
    action: 'task.update_deleted',
    entityType: 'Task',
    entityId: task._id,
    before: { body: comment.body, author: comment.authorName },
  });
}

/** Who may be @mentioned on a task: its private members if it has any, otherwise all staff. */
export async function mentionableForTask(taskId: string): Promise<MentionableUser[]> {
  const task = await getTask(taskId);
  if (!task) return [];
  const members = await assignableUserIdsForTask(task);
  return mentionableUsers(members);
}

/** Adds to a task's conversation, on its ticket when it has one; see listTaskComments. */
export async function addTaskComment(
  taskId: string,
  body: string,
  mentionIds: string[] = [],
  images: IncomingFile[] = [],
): Promise<void> {
  const text = body.trim() || (images.length ? 'Image update' : '');
  if (!text) throw new Error('Write a comment before posting it.');
  if (text.length > 4_000) throw new Error('A comment can be up to 4,000 characters.');

  const task = await getTask(taskId);
  if (!task) throw new Error('Task not found.');

  const context = getContext();
  const author = await UserModel.findOne({
    _id: context.userId,
    tenantId: context.tenantId,
  }).select('name');
  const authorName = author?.name ?? 'Unknown agent';
  const now = new Date();

  const sourceTicketId = await sourceTicketIdFor(task);
  const attachments = await storeTaskImages(images);
  const cleanupImages = async (error: unknown): Promise<never> => {
    await Promise.allSettled(attachments.map((file) => fileStorage().remove(file.storageKey)));
    throw error;
  };
  if (sourceTicketId) {
    await TicketMessageModel.create({
      tenantId: context.tenantId,
      ticketId: sourceTicketId,
      attachments,
      visibility: 'internal',
      direction: 'outbound',
      body: text,
      authorUserId: context.userId,
      authorName,
      channel: 'agent',
    }).catch(cleanupImages);
    await TicketModel.updateOne(
      { _id: sourceTicketId, tenantId: context.tenantId },
      { $set: { lastActivityAt: now } },
    );
  } else {
    await TaskCommentModel.create({
      tenantId: context.tenantId,
      taskId: task._id,
      attachments,
      body: text,
      authorUserId: context.userId,
      authorName,
    }).catch(cleanupImages);
  }

  await tasks().updateOne({ _id: task._id }, { $set: { lastActivityAt: now } });

  if (mentionIds.length > 0) {
    await alertMentioned({
      body: text,
      chosenIds: mentionIds,
      candidates: await mentionableForTask(taskId),
      subject: `[${task.number}] ${authorName} mentioned you`,
      where: `task ${task.number} ${task.title}`,
      link: `${appBaseUrl()}/tasks/${task._id}`,
      authorName,
    });
  }
}

export interface CreateTaskInput {
  spaceId: string;
  title: string;
  description?: string;
  priority?: Priority;
  assigneeIds?: string[];
  startAt?: string | null;
  endAt?: string | null;
  estimateMinutes?: number | null;
  organisationId?: string | null;
  folderId?: string | null;
  /** Adding straight into a column, from the board. Anything else opens in the first column. */
  status?: string;
  /** Set when support escalates a ticket, so work updates on the task can reach that ticket. */
  sourceTicketId?: string | null;
  sourceTeamsMessageUrl?: string | null;
}

/**
 * Work inside a private folder can only be given to that folder's members.
 *
 * The alternative is creating a task its own owner cannot open, which is a worse outcome than any
 * refusal, and one nobody would think to look for.
 */
async function assertAssignable(
  folderId: string | null,
  assigneeIds: string[],
  spaceId?: string,
): Promise<void> {
  const spaceAllowed = spaceId ? await assignableSpaceMemberIds(spaceId) : null;
  if (spaceAllowed && assigneeIds.some((id) => !spaceAllowed.includes(id))) {
    throw new Error('That space is private, so work in it can only be assigned to its members.');
  }
  const allowed = await assignableMemberIds(folderId);
  if (!allowed) return;

  const outside = assigneeIds.filter((id) => !allowed.includes(id));

  if (outside.length > 0) {
    throw new Error(
      'That folder is private, so work in it can only go to its members. Add them to the folder first.',
    );
  }
}

/**
 * Who may own this task: the members of its private Space and private Folder, or null when
 * neither is private and anyone in the tenant may. Pickers use it so they never offer a person
 * the service would then refuse.
 */
export async function assignableUserIdsForTask(task: {
  spaceId: Types.ObjectId | string;
  folderId?: Types.ObjectId | string | null;
}): Promise<string[] | null> {
  const [spaceMembers, folderMembers] = await Promise.all([
    assignableSpaceMemberIds(String(task.spaceId)),
    assignableMemberIds(task.folderId ? String(task.folderId) : null),
  ]);
  if (spaceMembers && folderMembers) {
    return spaceMembers.filter((id) => folderMembers.includes(id));
  }
  return spaceMembers ?? folderMembers;
}

/**
 * Who a subtask may go to: the task's own assignees, because a subtask is a slice of their work.
 * An unassigned task falls back to whoever may own the task itself.
 */
export async function assignableUserIdsForSubtask(task: {
  spaceId: Types.ObjectId | string;
  folderId?: Types.ObjectId | string | null;
  assigneeIds: (Types.ObjectId | string)[];
}): Promise<string[] | null> {
  if (task.assigneeIds.length > 0) return task.assigneeIds.map(String);
  return assignableUserIdsForTask(task);
}

export async function createTask(input: CreateTaskInput): Promise<string> {
  await connectToDatabase();

  const space = await SpaceModel.findOne({
    _id: toObjectId(input.spaceId),
    tenantId: getContext().tenantId,
    deletedAt: null,
  });

  if (!space) throw new Error('Space not found.');

  const columns = [...space.statuses].sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));

  const column = input.status
    ? columns.find((candidate) => candidate.name === input.status)
    : columns[0];

  if (input.status && !column) {
    throw new Error(`${space.name} has no column called ${input.status}.`);
  }

  const firstColumn = column ?? columns[0];

  await assertAssignable(
    input.folderId ?? null,
    (input.assigneeIds ?? []).filter(Boolean),
    input.spaceId,
  );

  const assigneeIds = (input.assigneeIds ?? []).filter(Boolean).map((id) => toObjectId(id));

  const startAt = toDate(input.startAt);
  const endAt = toDate(input.endAt);

  const created = await tasks().create({
    number: await nextNumber('task'),
    title: input.title.trim(),
    description: input.description?.trim() || null,
    spaceId: space._id,
    folderId: toOptionalObjectId(input.folderId),
    status: firstColumn?.name ?? 'To do',
    priority: input.priority ?? 'normal',
    assigneeIds,
    primaryAssigneeId: assigneeIds[0] ?? null,
    startAt,
    endAt,
    estimateMinutes: input.estimateMinutes ?? null,
    sortOrder: Date.now(),
    organisationId: toOptionalObjectId(input.organisationId ?? space.organisationId),
    sourceTicketId: toOptionalObjectId(input.sourceTicketId),
    sourceTeamsMessageUrl: teamsMessageLink(input.sourceTeamsMessageUrl),
    isClosed: firstColumn?.isClosed ?? false,
    lastActivityAt: new Date(),
    createdById: getContext().userId,
  });

  // Written straight after creation: the repository's create typing takes Mongoose's own
  // sub-document array, and the plain record is what every other write already uses.
  await tasks().updateOne(
    { _id: created._id },
    { $set: { assignments: assignmentsAfter([], assigneeIds, []) } },
  );

  await recordAudit({
    action: 'task.created',
    entityType: 'Task',
    entityId: created._id,
    after: { number: created.number, title: created.title, space: space.name },
  });

  await alertNewAssignees(created, [], created.assigneeIds.map(String));

  // A task against a customer belongs on that customer's timeline, which is the whole point of
  // keeping one activity collection.
  if (created.organisationId) {
    await recordActivity({
      organisationId: created.organisationId,
      kind: 'task_created',
      summary: `${created.number} ${created.title}`,
      sourceModule: 'tasks',
      sourceId: created._id,
    });
  }

  return String(created._id);
}

/**
 * Moves a task kept in Personal into a Space, and a Folder if one is chosen (John's team, 17 Oct
 * 2026). It always lands in the Space's first column, whatever that is called, because a task that
 * has just joined shared work has not been started there. Assignees must be allowed in the target
 * Space and Folder, the same rule creating a task there would apply. Time already logged follows
 * the task, so reports by Space stay true. Only the owner of the Personal list may do this, and
 * only for a task that is in it: tasks already in a Space move by drag and drop as before.
 */
export async function moveTaskToSpace(
  id: string,
  input: { spaceId: string; folderId?: string | null },
): Promise<void> {
  await connectToDatabase();

  const context = getContext();
  const task = await tasks().findById(id);
  if (!task || task.deletedAt) throw new Error('Task not found.');

  const from = await SpaceModel.findOne({ _id: task.spaceId, tenantId: context.tenantId });
  if (!from?.isPersonal) throw new Error('Only a task kept in Personal can be moved to a Space.');
  if (String(from.ownerId) !== String(context.userId)) {
    throw new Error('Only the owner of this Personal list can move its tasks.');
  }

  const target = await SpaceModel.findOne({
    _id: toObjectId(input.spaceId),
    tenantId: context.tenantId,
    deletedAt: null,
  });
  if (!target || target.isPersonal || target.status === 'archived') {
    throw new Error('Choose a Space that is open.');
  }
  if (!(await canOpenSpace(String(target._id)))) {
    throw new Error('You are not a member of that private Space.');
  }

  const folderId = input.folderId || null;
  if (folderId) {
    const folder = await FolderModel.findOne({
      _id: toObjectId(folderId),
      tenantId: context.tenantId,
      spaceId: target._id,
      deletedAt: null,
    });
    if (!folder || folder.status === 'archived') {
      throw new Error('That folder is not in the Space you chose.');
    }
  }

  await assertAssignable(folderId, task.assigneeIds.map(String), String(target._id));

  const firstColumn = [...target.statuses].sort(
    (a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0),
  )[0];
  if (!firstColumn) throw new Error('That Space has no columns yet.');

  await tasks().updateOne(
    { _id: task._id },
    {
      $set: {
        spaceId: target._id,
        folderId: toOptionalObjectId(folderId),
        status: firstColumn.name,
        isClosed: firstColumn.isClosed ?? false,
        closedAt: firstColumn.isClosed ? new Date() : null,
        organisationId: task.organisationId ?? target.organisationId ?? null,
        sortOrder: Date.now(),
        lastActivityAt: new Date(),
      },
    },
  );

  // Logged time carries the Space it was recorded against, which reports group on.
  await TimeEntryModel.updateMany(
    { tenantId: context.tenantId, taskId: task._id },
    { $set: { spaceId: target._id } },
  );

  await recordAudit({
    action: 'task.moved_to_space',
    entityType: 'Task',
    entityId: task._id,
    before: { space: from.name },
    after: { space: target.name, folder: folderId, status: firstColumn.name },
  });
}

export async function moveTask(id: string, status: string): Promise<void> {
  await connectToDatabase();

  const task = await tasks().findById(id);
  if (!task) throw new Error('Task not found.');

  const space = await SpaceModel.findOne({
    _id: task.spaceId,
    tenantId: getContext().tenantId,
  });

  const column = space?.statuses.find((candidate) => candidate.name === status);
  if (!column) throw new Error('That column does not exist on this space.');

  const wasClosed = task.isClosed ?? false;

  await tasks().updateOne(
    { _id: task._id },
    {
      $set: {
        status: column.name,
        isClosed: column.isClosed ?? false,
        closedAt: column.isClosed ? new Date() : null,
        lastActivityAt: new Date(),
      },
    },
  );

  await recordAudit({
    action: 'task.moved',
    entityType: 'Task',
    entityId: task._id,
    ...changedFields({ status: task.status }, { status: column.name }),
  });

  if (!wasClosed && column.isClosed && task.organisationId) {
    await recordActivity({
      organisationId: task.organisationId,
      kind: 'task_completed',
      summary: `${task.number} ${task.title}`,
      sourceModule: 'tasks',
      sourceId: task._id,
    });
  }

  // Completion is useful to support even when the assignee did not leave a written update.
  // This is an internal system event, never a customer reply.
  const completedTicketId = !wasClosed && column.isClosed ? await sourceTicketIdFor(task) : null;
  if (completedTicketId) {
    const context = getContext();
    await TicketMessageModel.create({
      tenantId: context.tenantId,
      ticketId: completedTicketId,
      visibility: 'internal',
      direction: 'outbound',
      body: `Task ${task.number} marked complete.`,
      authorUserId: context.userId,
      authorName: 'COEX',
      channel: 'system',
    });
    await TicketModel.updateOne(
      { _id: completedTicketId, tenantId: context.tenantId },
      { $set: { lastActivityAt: new Date() } },
    );
  }
}

export interface UpdateTaskInput {
  title: string;
  description?: string;
  priority: Priority;
  assigneeIds: string[];
  startAt?: string | null;
  endAt?: string | null;
  estimateMinutes?: number | null;
  tags?: string[];
  folderId?: string | null;
}

export async function updateTask(id: string, input: UpdateTaskInput): Promise<void> {
  await connectToDatabase();

  const before = await tasks().findById(id);
  if (!before) throw new Error('Task not found.');

  await assertAssignable(
    input.folderId !== undefined
      ? (input.folderId ?? null)
      : before.folderId
        ? String(before.folderId)
        : null,
    input.assigneeIds.filter(Boolean),
    String(before.spaceId),
  );

  const assigneeIds = input.assigneeIds.filter(Boolean).map((value) => toObjectId(value));

  const startAt = toDate(input.startAt);
  const endAt = toDate(input.endAt);

  if (startAt && endAt && endAt <= startAt) {
    throw new Error('The end must come after the start.');
  }

  await alertNewAssignees(
    before,
    before.assigneeIds.map(String),
    assigneeIds.map(String),
    input.title.trim(),
  );

  const after = await tasks().updateOne(
    { _id: before._id },
    {
      $set: {
        title: input.title.trim(),
        description: input.description?.trim() || null,
        priority: input.priority,
        assigneeIds,
        assignments: assignmentsAfter(
          before.assignments ?? [],
          assigneeIds,
          before.assigneeIds.map(String),
        ),
        mySubtaskDoneByIds: (before.mySubtaskDoneByIds ?? []).filter((id) =>
          assigneeIds.some((current) => String(current) === String(id)),
        ),
        primaryAssigneeId: assigneeIds[0] ?? null,
        startAt,
        endAt,
        estimateMinutes: input.estimateMinutes ?? null,
        tags: input.tags ?? [],
        folderId: toOptionalObjectId(input.folderId),
        lastActivityAt: new Date(),
      },
    },
  );

  await recordAudit({
    action: 'task.updated',
    entityType: 'Task',
    entityId: before._id,
    ...changedFields(
      {
        title: before.title,
        priority: before.priority,
        startAt: before.startAt,
        endAt: before.endAt,
        assigneeIds: before.assigneeIds.map(String),
      },
      {
        title: after?.title,
        priority: after?.priority,
        startAt: after?.startAt,
        endAt: after?.endAt,
        assigneeIds: after?.assigneeIds.map(String),
      },
    ),
  });
}

/**
 * A one-field change from a list or a card.
 *
 * updateTask replaces the whole task, which is right for the task form and wrong for setting a
 * date from a row: anything the caller did not send would be wiped. patchTask touches only the
 * fields it is given, and recomputes planned hours whenever either date moves.
 */
export interface TaskPatch {
  priority?: Priority;
  description?: string | null;
  folderId?: string | null;
  startAt?: string | null;
  endAt?: string | null;
  assigneeIds?: string[];
  title?: string;
  tags?: string[];
}

export async function patchTask(id: string, patch: TaskPatch): Promise<void> {
  await connectToDatabase();

  const before = await tasks().findById(id);
  if (!before) throw new Error('Task not found.');

  const set: Record<string, unknown> = { lastActivityAt: new Date() };

  if (patch.priority) set.priority = patch.priority;

  if (patch.description !== undefined) set.description = patch.description?.trim() || null;

  if (patch.tags !== undefined) set.tags = patch.tags;

  if (patch.folderId !== undefined) {
    // Moving into a private folder has to respect the same rule as assigning into one.
    await assertAssignable(
      patch.folderId,
      (patch.assigneeIds ?? before.assigneeIds.map(String)).filter(Boolean),
      String(before.spaceId),
    );

    set.folderId = toOptionalObjectId(patch.folderId);
  }

  if (patch.title !== undefined) {
    const title = patch.title.trim();
    if (!title) throw new Error('A task needs a title.');
    set.title = title;
  }

  if (patch.assigneeIds) {
    await assertAssignable(
      before.folderId ? String(before.folderId) : null,
      patch.assigneeIds.filter(Boolean),
      String(before.spaceId),
    );

    const assigneeIds = patch.assigneeIds.filter(Boolean).map((value) => toObjectId(value));
    set.assigneeIds = assigneeIds;
    set.assignments = assignmentsAfter(
      before.assignments ?? [],
      assigneeIds,
      before.assigneeIds.map(String),
    );
    set.mySubtaskDoneByIds = (before.mySubtaskDoneByIds ?? []).filter((id) =>
      assigneeIds.some((current) => String(current) === String(id)),
    );
    set.primaryAssigneeId = assigneeIds[0] ?? null;
  }

  if (patch.startAt !== undefined || patch.endAt !== undefined) {
    const startAt = patch.startAt !== undefined ? toDate(patch.startAt) : (before.startAt ?? null);
    const endAt = patch.endAt !== undefined ? toDate(patch.endAt) : (before.endAt ?? null);

    if (startAt && endAt && endAt <= startAt) {
      throw new Error('The end must come after the start.');
    }

    set.startAt = startAt;
    set.endAt = endAt;
  }

  await tasks().updateOne({ _id: before._id }, { $set: set });

  if (patch.assigneeIds) {
    await alertNewAssignees(
      before,
      before.assigneeIds.map(String),
      patch.assigneeIds.filter(Boolean),
      typeof set.title === 'string' ? set.title : undefined,
    );
  }

  await recordAudit({
    action: 'task.updated',
    entityType: 'Task',
    entityId: before._id,
    ...changedFields(
      {
        priority: before.priority,
        startAt: before.startAt,
        endAt: before.endAt,
        ...(patch.assigneeIds ? { assigneeIds: before.assigneeIds.map(String) } : {}),
      },
      {
        priority: set.priority,
        startAt: set.startAt,
        endAt: set.endAt,
        ...(patch.assigneeIds ? { assigneeIds: patch.assigneeIds.filter(Boolean) } : {}),
      },
    ),
  });
}

export async function addSubtask(taskId: string, title: string): Promise<void> {
  await connectToDatabase();

  const task = await tasks().updateOne(
    { _id: toObjectId(taskId) },
    {
      $push: { subtasks: { title: title.trim(), done: false } },
      $set: { lastActivityAt: new Date() },
    },
  );

  if (!task) throw new Error('Task not found.');
}

/** One level of breakdown only: a subtask that needs subtasks of its own is really a task. */
export async function toggleSubtask(
  taskId: string,
  subtaskId: string,
  done: boolean,
): Promise<void> {
  await connectToDatabase();

  const task = await tasks().findById(taskId);
  if (!task) throw new Error('Task not found.');

  const subtask = task.subtasks.find((candidate) => String(candidate._id) === subtaskId);
  if (!subtask) throw new Error('Subtask not found.');

  if (!done && subtask.assigneeId) {
    task.mySubtaskDoneByIds = (task.mySubtaskDoneByIds ?? []).filter(
      (id) => String(id) !== String(subtask.assigneeId),
    );
  }
  subtask.done = done;
  subtask.completedAt = done ? new Date() : null;
  task.lastActivityAt = new Date();

  await task.save();
}

/**
 * Give one subtask to one person, or clear it. A subtask is often the half of a task somebody else
 * does, so it carries its own owner. Passing null unassigns it.
 */
export async function setSubtaskAssignee(
  taskId: string,
  subtaskId: string,
  assigneeId: string | null,
): Promise<void> {
  await connectToDatabase();

  const task = await tasks().findById(taskId);
  if (!task) throw new Error('Task not found.');

  const subtask = task.subtasks.find((candidate) => String(candidate._id) === subtaskId);
  if (!subtask) throw new Error('Subtask not found.');

  if (assigneeId) {
    const allowed = await assignableUserIdsForSubtask(task);
    if (allowed && !allowed.includes(assigneeId)) {
      throw new Error(
        task.assigneeIds.length > 0
          ? 'A subtask can only go to someone already assigned to its task.'
          : 'That person is not a member of this private Space or Folder.',
      );
    }
  }

  const previousAssigneeId = subtask.assigneeId ? String(subtask.assigneeId) : null;
  if (previousAssigneeId === assigneeId) return;

  if (assigneeId) {
    task.mySubtaskDoneByIds = (task.mySubtaskDoneByIds ?? []).filter(
      (id) => String(id) !== assigneeId,
    );
  }
  subtask.assigneeId = assigneeId ? toObjectId(assigneeId) : null;
  task.lastActivityAt = new Date();

  await task.save();

  if (assigneeId) {
    try {
      await alertStaff(
        'task_assigned',
        assigneeId,
        `[${task.number}] Subtask assigned to you: ${subtask.title}`,
        [
          `A subtask on task ${task.number} has been assigned to you.`,
          '',
          `Subtask: ${subtask.title}`,
          `Task: ${task.title}`,
          '',
          `${appBaseUrl()}/tasks/${task._id}`,
        ],
      );
    } catch (error) {
      console.error('Subtask alert skipped:', error instanceof Error ? error.message : error);
    }
  }
}

export async function addDocumentLink(
  taskId: string,
  rawUrl: string,
  title?: string,
): Promise<void> {
  await connectToDatabase();

  const parsed = parseDocumentLink(rawUrl);

  const task = await tasks().updateOne(
    { _id: toObjectId(taskId) },
    {
      $push: {
        documentLinks: {
          url: parsed.url,
          title: title?.trim() || parsed.suggestedTitle,
          addedById: getContext().userId,
          addedAt: new Date(),
        },
      },
      $set: { lastActivityAt: new Date() },
    },
  );

  if (!task) throw new Error('Task not found.');

  await recordAudit({
    action: 'task.document_linked',
    entityType: 'Task',
    entityId: task._id,
    after: { url: parsed.url },
  });
}

export async function removeDocumentLink(taskId: string, linkId: string): Promise<void> {
  await connectToDatabase();

  await tasks().updateOne(
    { _id: toObjectId(taskId) },
    { $pull: { documentLinks: { _id: toObjectId(linkId) } }, $set: { lastActivityAt: new Date() } },
  );
}

/**
 * Moving a task on the board.
 *
 * Position is stored rather than inferred from dates, because a board people drag things around on
 * has an order that means something to them and nothing to a computer. New position is the midpoint
 * between its neighbours, so a move rewrites one row rather than renumbering the column.
 */
export async function moveTaskToPosition(
  id: string,
  status: string,
  afterTaskId: string | null,
  beforeTaskId: string | null,
): Promise<void> {
  await connectToDatabase();

  const task = await tasks().findById(id);
  if (!task) throw new Error('Task not found.');

  if (task.status !== status) {
    await moveTask(id, status);
  }

  const [after, before] = await Promise.all([
    afterTaskId ? tasks().findById(afterTaskId) : null,
    beforeTaskId ? tasks().findById(beforeTaskId) : null,
  ]);

  const afterOrder = after?.sortOrder ?? null;
  const beforeOrder = before?.sortOrder ?? null;

  let sortOrder: number;

  if (afterOrder !== null && beforeOrder !== null) {
    sortOrder = (afterOrder + beforeOrder) / 2;
  } else if (afterOrder !== null) {
    sortOrder = afterOrder + 1000;
  } else if (beforeOrder !== null) {
    sortOrder = beforeOrder - 1000;
  } else {
    sortOrder = Date.now();
  }

  await tasks().updateOne({ _id: task._id }, { $set: { sortOrder, lastActivityAt: new Date() } });
}

export async function archiveTask(id: string): Promise<void> {
  await connectToDatabase();

  const removed = await tasks().softDelete({ _id: toObjectId(id) });
  if (!removed) throw new Error('Task not found.');

  await recordAudit({
    action: 'task.archived',
    entityType: 'Task',
    entityId: removed._id,
    before: { number: removed.number, title: removed.title },
  });
}

/**
 * Emails the people newly given a task. Anyone already on it heard the first time, and a failed
 * email never stops the assignment itself from saving.
 */
type Assignment = {
  userId: Types.ObjectId;
  assignedById?: Types.ObjectId | null;
  assignedAt: Date;
};

/**
 * The assignment record after the assignees change: people who stay keep who assigned them and
 * when, newcomers are recorded as assigned now by whoever is acting, and people taken off drop
 * out. Someone assigned before the record existed keeps no entry rather than a guessed one.
 */
function assignmentsAfter(
  previous: Iterable<Assignment>,
  nextIds: readonly Types.ObjectId[],
  beforeIds: readonly string[],
): Assignment[] {
  const at = new Date();
  const actor = getContext().userId ?? null;
  const earlier = Array.from(previous);
  return nextIds.flatMap((userId): Assignment[] => {
    const kept = earlier.find((entry) => String(entry.userId) === String(userId));
    if (kept) {
      return [
        {
          userId: kept.userId,
          assignedById: kept.assignedById ?? null,
          assignedAt: kept.assignedAt,
        },
      ];
    }
    if (beforeIds.includes(String(userId))) return [];
    return [{ userId, assignedById: actor, assignedAt: at }];
  });
}

async function alertNewAssignees(
  task: { _id: Types.ObjectId; number: string; title: string },
  beforeIds: string[],
  afterIds: string[],
  title = task.title,
): Promise<void> {
  const added = afterIds.filter((id) => !beforeIds.includes(id));
  for (const userId of added) {
    try {
      await alertStaff('task_assigned', userId, `[${task.number}] Assigned to you: ${title}`, [
        `Task ${task.number} has been assigned to you.`,
        '',
        title,
        '',
        `${appBaseUrl()}/tasks/${task._id}`,
      ]);
    } catch (error) {
      console.error('Task alert skipped:', error instanceof Error ? error.message : error);
    }
  }
}
