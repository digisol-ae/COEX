import { SidebarFrame } from './sidebar-controls';
import { DigisolLogo } from '@/components/digisol-logo';
import Link from 'next/link';
import type { NavigationGroup } from './navigation';
import { NavigationTree } from './navigation-tree';

/**
 * The panel beside the rail.
 *
 * Light rather than dark, so the eye travels from the dark rail into the working area without a
 * second heavy block in the middle. It holds the workspace name, a way to add something, and the
 * list of what is inside the current area.
 */
export function Sidebar({
  groups,
  tenantName,
  canManageTasks,
  counts,
}: {
  groups: NavigationGroup[];
  tenantName: string;
  canManageTasks: boolean;
  counts?: Partial<Record<string, number>>;
}) {
  return (
    <SidebarFrame>
      <aside className="sidebar-glow hidden w-60 shrink-0 flex-col border-r border-[var(--color-line)] md:flex">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href="/dashboard" aria-label={`${tenantName} home`} title={tenantName}>
            <DigisolLogo priority />
          </Link>
        </div>

        <div className="flex-1 overflow-y-auto px-2 pb-6">
          <NavigationTree groups={groups} canManageTasks={canManageTasks} counts={counts} />
        </div>
      </aside>
    </SidebarFrame>
  );
}
