'use client';

import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';
import { useSyncExternalStore } from 'react';
import { clsx } from 'clsx';
import { DESK, HOME, type NavigationGroup } from './navigation';
import {
  getCollapsedSnapshot,
  getServerSnapshot,
  subscribe,
  toggleCollapsed,
} from './collapsed-store';
import { SpaceTree } from './space-tree';

/**
 * The menu itself, shared by the panel and the phone drawer.
 *
 * One implementation rather than two, because a menu that exists twice drifts: a link gets added
 * to one and forgotten in the other, and only a user on a client site ever finds out.
 */
export function NavigationTree({
  groups,
  onNavigate,
  canManageTasks,
  counts,
}: {
  groups: NavigationGroup[];
  onNavigate?: () => void;
  canManageTasks: boolean;
  /** A number beside a link, keyed by its href. */
  counts?: Partial<Record<string, number>>;
}) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const returnTo = `${pathname}${searchParams.size ? `?${searchParams.toString()}` : ''}`;
  const collapsed = useSyncExternalStore(subscribe, getCollapsedSnapshot, getServerSnapshot);

  // The most specific link wins, so /time/all does not also light up /time (My timesheet).
  const allHrefs = [
    HOME.href,
    DESK.href,
    ...groups.flatMap((group) => group.items.map((i) => i.href)),
  ];
  const isActive = (href: string) => {
    const matches = (candidate: string) =>
      pathname === candidate || pathname.startsWith(`${candidate}/`);
    return matches(href) && !allHrefs.some((other) => other.length > href.length && matches(other));
  };

  return (
    <nav className="space-y-4">
      <div className="space-y-0.5">
        <NavigationLink
          href={HOME.href}
          label={HOME.label}
          active={isActive(HOME.href)}
          onNavigate={onNavigate}
          heading
        />
        <NavigationLink
          href={DESK.href}
          label={DESK.label}
          active={isActive(DESK.href)}
          onNavigate={onNavigate}
          heading
        />
      </div>

      {groups.map((group) => {
        if (group.id === 'setup')
          return (
            <NavigationLink
              key={group.id}
              href={`/setup?${new URLSearchParams({ returnTo })}`}
              label={group.label}
              active={pathname === '/setup' || pathname.startsWith('/setup/')}
              onNavigate={onNavigate}
              heading
            />
          );
        // The group holding the current page stays open whatever was collapsed before, so nobody
        // can lose the page they are looking at.
        const holdsCurrentPage = group.items.some((item) => isActive(item.href));
        const open = holdsCurrentPage || !collapsed.includes(group.id);

        return (
          <div key={group.id}>
            <button
              type="button"
              onClick={() => toggleCollapsed(group.id)}
              aria-expanded={open}
              className={clsx(
                'navigation-heading flex w-full items-center justify-between rounded-[var(--radius-control)] px-2 py-1 uppercase transition-opacity hover:opacity-75 max-md:min-h-11',
                holdsCurrentPage && 'navigation-section-active',
              )}
            >
              {group.label}
              <Chevron open={open} />
            </button>

            {open ? (
              <div className="mt-0.5 space-y-0.5">
                {group.items.map((item) =>
                  // Spaces carries a tree of its own: folders, tasks, then subtasks, on expand.
                  item.href === '/spaces' ? (
                    <SpaceTree key={item.href} canManage={canManageTasks} />
                  ) : (
                    <NavigationLink
                      key={item.href}
                      // With contracts waiting for renewal the link opens just those; the page
                      // has a link back to all of them.
                      href={
                        item.href === '/contracts' && counts?.[item.href]
                          ? '/contracts?filter=due'
                          : item.href
                      }
                      label={item.label}
                      active={isActive(item.href)}
                      onNavigate={onNavigate}
                      count={counts?.[item.href]}
                    />
                  ),
                )}
              </div>
            ) : null}
          </div>
        );
      })}

      <Link
        href="/menu-order"
        onClick={onNavigate}
        className="block px-2 py-2 text-[11px] text-[var(--color-ink-subtle)] underline-offset-4 hover:text-[var(--color-ink-muted)] hover:underline"
      >
        Arrange my menu
      </Link>
    </nav>
  );
}

function NavigationLink({
  href,
  label,
  active,
  onNavigate,
  count,
  heading = false,
}: {
  href: string;
  label: string;
  active: boolean;
  onNavigate?: () => void;
  count?: number;
  /** A top level link (Dashboard, My desk) is set like the group headings, so they line up. */
  heading?: boolean;
}) {
  return (
    <Link
      href={href}
      onClick={onNavigate}
      aria-current={active ? 'page' : undefined}
      className={clsx(
        // The generous height is for thumbs: 44 pixels is the smallest target reliably hit on a
        // phone.
        'flex items-center justify-between rounded-[var(--radius-control)] px-2 py-2 text-[13px] transition-colors max-md:min-h-11 max-md:text-sm',
        heading && 'navigation-heading uppercase',
        active
          ? heading
            ? 'navigation-section-active'
            : 'navigation-active pl-3'
          : heading
            ? 'hover:bg-[var(--color-surface-muted)]'
            : 'text-[var(--color-ink-muted)] hover:bg-[var(--color-surface-muted)] hover:text-[var(--color-ink)]',
      )}
    >
      {label}
      {count ? (
        <span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--color-brand-red)] px-1 text-[9px] font-medium text-white">
          {count > 99 ? '99+' : count}
        </span>
      ) : null}
    </Link>
  );
}

function Chevron({ open }: { open: boolean }) {
  return (
    <svg
      width="12"
      height="12"
      viewBox="0 0 12 12"
      fill="none"
      aria-hidden="true"
      className={clsx('transition-transform', open ? 'rotate-90' : 'rotate-0')}
    >
      <path
        d="M4.5 2.5L8 6l-3.5 3.5"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
